
<div class="" align="center">

  <a href="logout.php">로그아웃</a>
</div>
</body>
</html>
