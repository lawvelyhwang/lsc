<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="bootstrap.min.css">
  <link rel="stylesheet" href="bootstrap.css">


  <title></title>
  <meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, width=device-width, height=device-height">
  <style media="screen">
  .btn-primary{
    background-color: #fdf8d6 !important;
    border-color: #ccc !important;
    color: black;
  }
  </style>
</head>
<body>
  <br>
  <div align="center">
    <div class="btn-group" role="group" aria-label="First group" align="center">
      <a class="" href="adminmain.php" id="list">일일 명단</a>
      <a class="" href="adminweek.php" id="listweek">주별 명단</a>
      <a class="" href="rollbookAdmin.php" id="rollbook">출석부</a>
    </div>
  </div>
