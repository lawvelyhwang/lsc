<?php
session_start();
include("adminhead.php");
include("config.php");
date_default_timezone_set("Asia/Seoul");

//  echo date("ymdhi");
  if($_GET['date'] == null){
    $today = substr(date("md"),1);
  }else{
    $today = $_GET['date'];
  }
$dayIndex;
$weekIndex;
  switch ($today%7) {
    case 1 :
    $dayIndex = "mon";
    break;
    case 2 :
    $dayIndex = "tue";
    break;
    case 3 :
    $dayIndex = "wed";
    break;
    case 4 :
    $dayIndex = "thu";
    break;
    case 5 :
    $dayIndex = "fri";
    break;
    case 6 :
    $dayIndex = "sat";
    break;
    case 0 :
    $dayIndex = "sun";
    break;
  }
  $todaya = $today;
  if ($today >=1000) {
    $todaya = $today - 70;
  }
  switch (floor(($todaya-1)/7)) {
    case 129 :
    $weekIndex = "1";
    break;
    case 130 :
$weekIndex = "2";    break;
    case 131 :
$weekIndex = "3";    break;
    case 132 :
$weekIndex = "4";    break;
    case 133 :
$weekIndex = "5";    break;
    case 134 :
$weekIndex = "6";    break;
    case 135 :
$weekIndex = "7";    break;
  }
  ?>

  <script type="text/javascript">
      document.getElementById("list").className = "btn btn-primary";
      document.getElementById("listweek").className = "btn btn-default";
      document.getElementById("rollbook").className = "btn btn-default";

  </script>

  <div class="" align="center">
    <h1>일일 면담 일정 관리</h1>

  </div>
  <form class="" action="adminmain.php" method="get">
    <div class="input-group">
      <input type="text" class="form-control" placeholder="날짜 입력 ex) 901" name="date">
      <span class="input-group-btn">
        <button class="btn btn-default" type="submit">검색</button>
      </span>
    </div>
  </form>

  <?php
  /*$sql = "select {$dayIndex}, B.id, B.nowW, B.w1date, B.w1hour, B.w1, B.w1tf, B.w2date,
  B.w2hour, B.w2, B.w2tf, B.w3date, B.w3hour, B.w3, B.w3tf, B.w4date, B.w4hour, B.w4, B.w4tf,
  B.w5date, B.w5hour, B.w5, B.w5tf, B.w1file, B.w2file, B.w3file, B.w4file, B.w5file
   from curriculum_week{$weekIndex} join userprogress as B on substring_index(curriculum_week{$weekIndex}.{$dayIndex},\"-\",1) = B.id";*/

   $sql = "select {$dayIndex}, substring(B.id,1,length(B.id)) as id , B.nowW, B.w1date, B.w1hour, B.w1, B.w1tf, B.w2date,
   B.w2hour, B.w2, B.w2tf, B.w3date, B.w3hour, B.w3, B.w3tf, B.w4date, B.w4hour, B.w4, B.w4tf,
   B.w5date, B.w5hour, B.w5, B.w5tf, B.w1file, B.w2file, B.w3file, B.w4file, B.w5file
    from curriculum_week{$weekIndex} join userprogress as B on substring(curriculum_week{$weekIndex}.{$dayIndex},1,length(curriculum_week{$weekIndex}.{$dayIndex})-2) = B.id";
  echo "<div align=\"center\"><br>날짜 검색 결과 : ".$today."<br><br></div>";
  
 if($_SESSION['login_user'] == kalitsma){
   if($_GET['date']!=null){

  $result = mysqli_query($db, $sql );


  echo "<div style=\"text-align: center;\">
  <table class=\"table\" style=\"width: 100%; align: center; margin-right: auto; margin-left: auto;\">";

  echo "<tr class=\"warning\">
  <td>시간</td>
  <td>학생</td>
  <td>회차</td>
  <td>클래스</td>
  </tr>";
  echo "<tr class=\"warning\">
  <td>파일</td>
  <td>문자</td>
  <td>세부</td>
  <td>확인</td>
  </tr><tbody><tr><td colspan=\"4\"></tr>";
  while($row = mysqli_fetch_assoc($result)){
    $realW;
    if($row['w1date'] == $_GET['date']){
      $realW = 1;
    }elseif ($row['w2date'] == $_GET['date']) {
      $realW = 2;
    }elseif ($row['w3date'] == $_GET['date']) {
      $realW = 3;
    }elseif ($row['w4date'] == $_GET['date']) {
     $realW = 4;
    }elseif ($row['w5date'] == $_GET['date']) {
      $realW = 5;
    }
    $sql = "select `userdb`.id, `userdb`.password, `userdb`.name, `userdb`.pNumber,
    `userdb`.class, `userdb`.school, `userdb`.major, `userdb`.gpa, `userdb`.gpaIndex, `userdb`.leetApure,
    `userdb`.leetBpure, `userdb`.eng, `userdb`.engIndex, b.nowW, b.w1, b.w2, b.w3, b.w4, b.w5, b.w1tf, b.w2tf, b.w3tf, b.w4tf, b.w5tf, b.w1file, b.w2file, b.w3file, b.w4file, b.w5file
     from userdb left join userprogress as B on userdb.id = B.id where userdb.id = '{$row['id']}'";
    $resultSub = mysqli_query($db,$sql);
    $rowSub = mysqli_fetch_assoc($resultSub);
    $now = "w" . $realW;
    echo "<tr>
    <td>{$rowSub[$now]}</td>
    <td>{$rowSub['name']}</td>
    <td>{$realW}회차</td>
    <td>{$rowSub['class']}</td>
    </tr>";

    echo "<tr>
    <td>";
    $w = "w".$realW."file";
    $file = "./uploads/".$rowSub[$w];
    $w = "w".$realW."tf";
    $tfValue;
    if ($row[$w]=='true') {
      $tfValue = "P";
    }else{
      $tfValue = "F";
    }
    if (is_file($file)) {
      echo "<a class=\"btn btn-default\" href=\"download.php?index={$realW}&id={$rowSub['id']}&date={$_GET['date']}\">다운로드</a>";
    }else {
      echo "No File";
    }
    $phonenumb = substr($rowSub['pNumber'], 2);
    echo "</td>
    <td><a href=\"sms:+82{$phonenumb}\" class=\"btn btn-default\">문자</a></td>

    <td>";
      echo "<form name=\"userform\" method=\"post\" action=\"./analysis/process.php?date={$_GET['date']}\">";
      $sql = "select * from userdb where `id` = '{$rowSub['id']}'";
      $result12 = mysqli_query($db, $sql);
      $row12 = mysqli_fetch_assoc($result12);
      echo "<input type=\"hidden\" name=\"name\" value=\"{$row12['name']}\">";
      echo "<input type=\"hidden\" name=\"age\" value=\"{$row12['age']}\">";
      echo "<input type=\"hidden\" name=\"school\" value=\"{$row12['school']}\">";
      echo "<input type=\"hidden\" name=\"major\" value=\"{$row12['major']}\">";
      echo "<input type=\"hidden\" name=\"schoolsub\" value=\"{$row12['schoolsub']}\">";
      echo "<input type=\"hidden\" name=\"leetApure\" value=\"{$row12['leetApure']}\">";
      echo "<input type=\"hidden\" name=\"leetBpure\" value=\"{$row12['leetBpure']}\">";
      echo "<input type=\"hidden\" name=\"radio\" value=\"{$row12['gpaIndex']}\">";
      echo "<input type=\"hidden\" name=\"schoolScore\" value=\"{$row12['gpa']}\">";
      echo "<input type=\"hidden\" name=\"radioEng\" value=\"{$row12['engIndex']}\">";
      echo "<input type=\"hidden\" name=\"engScore\" value=\"{$row12['eng']}\">";


    echo "<input type=\"submit\" class=\" btn btn-default \" value=\"정보\">
    </form>
  </td>

    <td><a href=\"pfCheck.php?id={$rowSub['id']}&nowW={$row['nowW']}&date={$_GET['date']}\" class=\"btn btn-default\">확인</a> <br>p/f : {$tfValue}</td>
    </tr>";

    echo "<tr>
    <td colspan=\"4\"></td>
    </tr>";
  }
  echo "</tbody></table>";










}
 }else{
  $target_url = "index.php";
  header("Location: {$target_url}");
}
      echo "</div>";


  include("adminfoot.php");
  ?>
