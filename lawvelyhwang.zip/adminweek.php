<?php
session_start();
include("adminhead.php");
include("config.php");
date_default_timezone_set("Asia/Seoul");
?>

<script type="text/javascript">
    document.getElementById("list").className = "btn btn-default";
    document.getElementById("listweek").className = "btn btn-primary";
    document.getElementById("rollbook").className = "btn btn-default";

</script>

<div class="" align="center">

  <?php
 if($_SESSION['login_user'] != kalitsma){
   $target_url = "index.php";
   header("Location: {$target_url}");
 }
 
  echo "<form action=\"adminweek.php\" method=\"get\">"; ?>
    <div class="input-group" style="width: 80%;">
      <select class="form-control" name="aweek">
        <option>다른 기간 선택</option>
        <option value="1">9/4 ~ 9/10</option>
        <option value="2">9/11 ~ 9/17</option>
        <option value="3">9/18 ~ 9/24</option>
        <option value="4">9/25 ~ 10/1</option>
        <option value="5">10/2 ~ 10/8</option>
        <option value="6">10/9 ~ 10/14</option>
      </select>
      <span class="input-group-btn">
        <button class="btn btn-default" type="submit">검색</button>
      </span>
    </div>
  </form>
  <br>
<div class="" align="center">
  <table class="table" style="width: 80%; text-align: center;">
    <tr>
      <td>시간</td>
      <td>월</td>
      <td>화</td>
      <td>수</td>
      <td>목</td>
      <td>금</td>
      <td>토</td>
      <td>일</td>
    </tr>

    <?php
    function getResult($table, $searchCol, $searchVal, $option='where'){
      global $db;
      $sql = "select * from ".$table;

      if($option == 'where'){
        $option = " where `".$searchCol."` = '".$searchVal."'";
        $sql .= $option;
      }
      $result = mysqli_query($db, $sql);
//      echo $sql." | ";
      return $result;
    }

      $tableName = 'calander';
      if($_GET['aweek']==null){
      $result = getResult($tableName, 'week', $_GET['index']);
    }else{
      $result = getResult($tableName, 'week', $_GET['aweek']);
    }
      while($row = mysqli_fetch_assoc($result)){
        echo "<tr>";
        echo "<td>"."</td>";
        echo "<td>".$row['mon']."</td>";
        echo "<td>".$row['tue']."</td>";
        echo "<td>".$row['wed']."</td>";
        echo "<td>".$row['thu']."</td>";
        echo "<td>".$row['fri']."</td>";
        echo "<td>".$row['sat']."</td>";
        echo "<td>".$row['sun']."</td>";
        echo "</tr>";
      }
      if($_GET['aweek']==null){
      $tableName = 'curriculum_week'.$_GET['index'];
    }else{
      $tableName = 'curriculum_week'.$_GET['aweek'];
    }

      $result = getResult($tableName, '','','all');

      function timeClac($index){
        $hour = floor(($index+1)/2) +9;
        $min = $index%2;
        $time = $hour . ":";
        if($min == 0){
          $time .="30";
        }else{
          $time .="00";
        }
        return $time;
      }

      function dayCalc($index, $dayValue, $day, $tableName, $checker){

        if($dayValue == ''){
          $url = "reserveProcess.php?index=".$index."&day=".$day."&tableName=".$tableName;
            $content = " - ";
          return $content;
        }else if($dayValue == '수업'){
            return " class=\"is-hidden\">수업";
        }else if($dayValue == '이동중'){
            return " class=\"is-hidden\">이동중";
        }else{
          return " class=\"is-hidden\">{$dayValue}";
        }
      }

      function idtoname($id){
        global $db;
        if($id == '수업'){
          return '수업';
        }elseif ($id =='이동중') {
          return '이동중';
        }elseif ($id =='') {
          return '';
        }else{
//          echo $id.", ";
        $level = substr($id, -1, 1);
        $id = substr($id, 0, -2);
        $sql = "select id, name from userdb where `id` = '{$id}'";
        $result = mysqli_query($db, $sql);

        $row = mysqli_fetch_assoc($result);
        $name = $row['name']." {$level}차";
  //      echo $id.", ".$level."<br>";
        return $name;}
      }
      while($row = mysqli_fetch_assoc($result)){
        $time = timeClac($row['time']);
        $dayValue = array(
          dayCalc($row['time'],idtoname($row['mon']),1,$tableName,1),
          dayCalc($row['time'],idtoname($row['tue']),2,$tableName,0),
          dayCalc($row['time'],idtoname($row['wed']),3,$tableName,1),
          dayCalc($row['time'],idtoname($row['thu']),4,$tableName,0),
          dayCalc($row['time'],idtoname($row['fri']),5,$tableName,0),
          dayCalc($row['time'],idtoname($row['sat']),6,$tableName,0),
          dayCalc($row['time'],idtoname($row['sun']),7,$tableName,0)
        );

        echo "<tr>";
        echo "<td>".$time."</td>";
        echo "<td".$dayValue[0]."</td>";
        echo "<td".$dayValue[1]."</td>";
        echo "<td".$dayValue[2]."</td>";
        echo "<td".$dayValue[3]."</td>";
        echo "<td".$dayValue[4]."</td>";
        echo "<td".$dayValue[5]."</td>";
        echo "<td".$dayValue[6]."</td>";
        echo "</tr>";
      }
     ?>

  </table>
</div>
<?php
  if($_GET['date'] == null){
    $today = substr(date("md"),1);
  }else{
    $today = $_GET['date'];
  }
$dayIndex;
$weekIndex;
  switch ($today%7) {
    case 1 :
    $dayIndex = "mon";
    break;
    case 2 :
    $dayIndex = "tue";
    break;
    case 3 :
    $dayIndex = "wed";
    break;
    case 4 :
    $dayIndex = "thu";
    break;
    case 5 :
    $dayIndex = "fri";
    break;
    case 6 :
    $dayIndex = "sat";
    break;
    case 7 :
    $dayIndex = "sun";
    break;
  }
  switch (floor($today/7)) {
    case 129 :
    $weekIndex = "1";
    break;
    case 130 :
$weekIndex = "2";    break;
    case 131 :
$weekIndex = "3";    break;
    case 132 :
$weekIndex = "4";    break;
    case 133 :
$weekIndex = "5";    break;
    case 134 :
$weekIndex = "6";    break;
    case 135 :
$weekIndex = "7";    break;
  }
  include("adminfoot.php");
  ?>
