<?php
  include("head.php");
?>

    <h1 class="heading" align="center">로스쿨 정량분석</h1><br>

    <div align="center">
      * 이 자료는 2017 년도 요강과 2017 년도 합격자 평균을 기준으로 만들어졌습니다.<br>
      * 추천된 학교들부터 정량을 분석해 보시길 바랍니다.<br>
      * 2018 년도 요강과 학교별 정성요소를 고려하여 변호사님과 상담 후에 학교를 결정하셔서 꼭 합격하시길 빌겠습니다.<br><br><br>
    </div>
    <div class="container">
      <div class="jumbotron">
        <form class="" action="./analysis/process.php" method="post" name="score">
          <div class="row">
            <div class="col-md-6">
          <label class="field-label-2" for="leetAscore">언어이해 표준점수</label>
          <input class="form-control" data-name="leetAscore" id="leetAscore" maxlength="256" name="leetAscore" placeholder="언어이해 표준점수 입력란"
          required="required" type="text">
         </div>
          <div class="col-md-6">
          <label class="field-label-2" for="leetAPscore">언어이해 백분위</label>
          <input class="form-control" data-name="leetAPscore" id="leetAPscore" maxlength="256" name="leetAPscore" placeholder="언어이해 백분위 입력란"
          required="required" type="text">
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
          <label class="field-label-2" for="leetBscore">추리논증 표준점수</label>
          <input class="form-control" data-name="leetBscore" id="leetBscore" maxlength="256" name="leetBscore" placeholder="추리논증 표준점수 입력란"
          required="required" type="text">
        </div>
          <div class="col-md-6">
          <label class="field-label-2" for="leetBPscore">추리논증 백분위</label>
          <input class="form-control" data-name="leetBPscore" id="leetBPscore" maxlength="256" name="leetBPscore" placeholder="추리논증 백분위 입력란"
          required="required" type="text">
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">

              <label class="field-label-2" for="schoolScore">학부성적 원점수</label>
              <div>
                <div class="radio-button-field w-radio" style="float: left;margin-right: 10px;">
                  <input class="w-radio-input" data-name="radioSchool" id="40" name="radio" type="radio" value="4.0">
                  <label class="w-form-label" for="40">4.0</label>
                </div>
                <div class="radio-button-field w-radio" style="float: left;margin-right: 10px;">
                  <input class="w-radio-input" data-name="radioSchool" id="43" name="radio" type="radio" value="4.3">
                  <label class="w-form-label" for="43">4.3</label>
                </div>
                <div class="radio-button-field w-radio" style="float: left;margin-right: 10px;">
                  <input class="w-radio-input" checked="checked" data-name="radioSchool" id="45" name="radio" type="radio" value="4.5">
                  <label class="w-form-label" for="45">4.5</label>
                </div>
              </div>
              <input class="form-control" data-name="schoolScore" id="schoolScore" maxlength="256" name="schoolScore" placeholder="학부성적 원점수 입력란"
              required="required" type="text">

            </div>
            <div class="col-md-6">
              <label class="field-label-2" for="engScore">영어성적 원점수</label>
              <div>
                <div class="radio-button-field w-radio" style="float: left;margin-right: 10px;">
                  <input class="w-radio-input"checked="checked" data-name="radioEng" id="toeic" name="radioEng" type="radio" value="toeic">
                  <label class="w-form-label" for="toeic">TOEIC</label>
                </div>
                <div class="radio-button-field w-radio" style="float: left;margin-right: 10px;">
                  <input class="w-radio-input" data-name="radioEng" id="toefl" name="radioEng" type="radio" value="toefl">
                  <label class="w-form-label" for="toefl">TOEFL</label>
                </div>
                <div class="radio-button-field w-radio" style="float: left;margin-right: 10px;">
                  <input class="w-radio-input" data-name="radioEng" id="teps" name="radioEng" type="radio" value="teps">
                  <label class="w-form-label" for="teps">TEPS</label>
                </div>
              </div>
              <input class="form-control" data-name="engScore" id="engScore" maxlength="256" name="engScore" placeholder="영어성적 원점수 입력란"
              required="required" type="text">
              <input type="hidden" name="signState" value="">
            </div>
          </div>
          <br>
           <a class="btn btn-default btn-lg" href="./analysis/leetConvertTable.html" onclick="window.open(this.href, '_blanck', 'width=600, height=700'); return false">2018 리트 변환표</a>

                <input type="submit" class=" btn btn-default btn-lg " value="확인" style="float: right;">
                <br><br>

        </form>
<?php
  include("foot.php");
 ?>
