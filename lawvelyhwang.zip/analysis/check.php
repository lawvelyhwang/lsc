<html>
  <head>
  <meta charset="utf-8">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

  function drawChart() {
    var dataTable = new google.visualization.DataTable();
        dataTable.addColumn('string', 'schoolName');
        dataTable.addColumn('number', '25%');
        dataTable.addColumn('number', '50%');
        dataTable.addColumn('number', 'avg');
        dataTable.addColumn('number', '75%');
        // A column for custom tooltip content

      //  dataTable.addColumn('string', 'aaa');

        dataTable.addColumn({'type': 'string', 'role': 'tooltip', 'p': {'html': true}});
        dataTable.addColumn({type: 'string', role: 'style'});
        dataTable.addRows([
          ['강원대', 117, 111.2, 111.9, 107.4, '강원대 <br>상위25% : 117 <br>상위50% : 111.2 <br>상위75% : 107.4 <br>평균    : 111.9', null],
['건국대', 120.7, 118.7, 121.45, 126.5, '건국대 <br>상위25% : 120.7 <br>상위50% : 118.7 <br>상위75% : 126.5 <br>평균    : 121.45', null],
['경북대', 114.89, 111.01, 110.27, 105.51, '경북대 <br>상위25% : 114.89 <br>상위50% : 111.01 <br>상위75% : 105.51 <br>평균    : 110.27', null],
['경희대', 117, 113, 109, 101.5, '경희대 <br>상위25% : 117 <br>상위50% : 113 <br>상위75% : 101.5 <br>평균    : 109', null],
['고려대', 130.2, 126.4, 126.4, 124.5, '고려대 <br>상위25% : 130.2 <br>상위50% : 126.4 <br>상위75% : 124.5 <br>평균    : 126.4', null],
['동아대', 105.4, 99.7, 100.1, 94.1, '동아대 <br>상위25% : 105.4 <br>상위50% : 99.7 <br>상위75% : 94.1 <br>평균    : 100.1', null],
['부산대', 117, 111.4, 111.2, 110.5, '부산대 <br>상위25% : 117 <br>상위50% : 111.4 <br>상위75% : 110.5 <br>평균    : 111.2', null],
['서강대', 118.9, 118.9, 116.7, 105.4, '서강대 <br>상위25% : 118.9 <br>상위50% : 118.9 <br>상위75% : 105.4 <br>평균    : 116.7', null],
['서울대', 139.3, 135.4, 134.2, 131.5, '서울대 <br>상위25% : 139.3 <br>상위50% : 135.4 <br>상위75% : 131.5 <br>평균    : 134.2', null],
['서울시립대', 124.5, 120.6, 119.55, 113.2, '서울시립대 <br>상위25% : 124.5 <br>상위50% : 120.6 <br>상위75% : 113.2 <br>평균    : 119.55', null],
['성균관대', 130.2, 126.4, 125.5, 120.7, '성균관대 <br>상위25% : 130.2 <br>상위50% : 126.4 <br>상위75% : 120.7 <br>평균    : 125.5', null],
['아주대', 120.7, 122.6, 111.5, 103.5, '아주대 <br>상위25% : 120.7 <br>상위50% : 122.6 <br>상위75% : 103.5 <br>평균    : 111.5', null],
['연세대', 128, 125, 126, 121, '연세대 <br>상위25% : 128 <br>상위50% : 125 <br>상위75% : 121 <br>평균    : 126', null],
['영남대', 109.3, 99.7, 100.92, 93.9, '영남대 <br>상위25% : 109.3 <br>상위50% : 99.7 <br>상위75% : 93.9 <br>평균    : 100.92', null],
['원광대', 103.6, 101.6, 99.7, 95.9, '원광대 <br>상위25% : 103.6 <br>상위50% : 101.6 <br>상위75% : 95.9 <br>평균    : 99.7', null],
['이화여대', 112.5, 128.3, 116, 111.1, '이화여대 <br>상위25% : 112.5 <br>상위50% : 128.3 <br>상위75% : 111.1 <br>평균    : 116', null],
['인하대', 116.8, 113, 112.7, 109.3, '인하대 <br>상위25% : 116.8 <br>상위50% : 113 <br>상위75% : 109.3 <br>평균    : 112.7', null],
['전남대', 111.3, 105.4, 108.48, 108.48, '전남대 <br>상위25% : 111.3 <br>상위50% : 105.4 <br>상위75% : 108.48 <br>평균    : 108.48', null],
['전북대', null, null, 110.86, null, '전북대 <br>상위25% : 0 <br>상위50% : 0 <br>상위75% : 0 <br>평균    : 110.86', null],
['제주대', 101.7, 97.8, 98.4, 99.7, '제주대 <br>상위25% : 101.7 <br>상위50% : 97.8 <br>상위75% : 99.7 <br>평균    : 98.4', null],
['중앙대', 114.91, 114.55, 114.18, 114.18, '중앙대 <br>상위25% : 114.91 <br>상위50% : 114.55 <br>상위75% : 114.18 <br>평균    : 114.18', null],
['충남대', 118.9, 118.9, 112.08, 103.5, '충남대 <br>상위25% : 118.9 <br>상위50% : 118.9 <br>상위75% : 103.5 <br>평균    : 112.08', null],
['충북대', 111.17, 107.46, 107.76, 105.29, '충북대 <br>상위25% : 111.17 <br>상위50% : 107.46 <br>상위75% : 105.29 <br>평균    : 107.76', null],
['한국외대', 122.5, 118.8, 119, 114.9, '한국외대 <br>상위25% : 122.5 <br>상위50% : 118.8 <br>상위75% : 114.9 <br>평균    : 119', null],
['한양대', 125.86, 120.88, 121.54, 116.87, '한양대 <br>상위25% : 125.86 <br>상위50% : 120.88 <br>상위75% : 116.87 <br>평균    : 121.54', null]

      // Treat first row as data as well.
    ]);

    var options = {
      tooltip: {isHtml: true},
      legend:'none',
      hAxis: {
        slantedText: true,
        slantedTextAngle: 90
      }
    };

    var chart = new google.visualization.CandlestickChart(document.getElementById('chart_div'));

    chart.draw(dataTable, options);
  }
    </script>
  </head>
  <body>
    <div id="chart_div" style="width: 900px; height: 500px;"></div>
  </body>
</html>
