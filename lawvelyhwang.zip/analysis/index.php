
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <title>로스쿨 모의 지원</title>
  </head>
  <body>
    <div class="" align="center">
      페이지 수리중입니다.
    </div>
    <div align="center">
      <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
      <!-- lawcalc.xyz-반응형 -->
      <ins class="adsbygoogle"
           style="display:block"
           data-ad-client="ca-pub-8511691406076432"
           data-ad-slot="7887483485"
           data-ad-format="auto"></ins>
      <script>
      (adsbygoogle = window.adsbygoogle || []).push({});
      </script>
    </div>
  </body>
</html>
