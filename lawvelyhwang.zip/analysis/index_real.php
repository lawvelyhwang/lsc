    <?php
    $mobileKeyWords = ['iPhone', 'iPod', 'BlackBerry', 'Android', 'Windows CE', 'Windows CE;', 'LG', 'MOT', 'SAMSUNG', 'SonyEricsson', 'Mobile', 'Symbian', 'Opera Mobi', 'Opera Mini', 'IEmobile'];
    for($i = 0; $i < count($mobileKeyWords); $i++)
    {
    if(strpos($_SERVER['HTTP_USER_AGENT'],$mobileKeyWords[$i]) == true)
     {
    header('Location: http://lawschoolcalc.xyz/indexmobile.php/');
    exit;
     }
    }
    ?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <title>로스쿨 모의 지원</title>
  </head>
  <body>

    <h1 class="heading">로스쿨 모의지원</h1><br>
    <div class="container">
      <div class="jumbotron">
        <form class="" action="process.php" method="post" name="score">
          <div class="row">
            <div class="col-md-6">
          <label class="field-label-2" for="leetAscore">언어이해 표준점수</label>
          <input class="form-control" data-name="leetAscore" id="leetAscore" maxlength="256" name="leetAscore" placeholder="언어이해 표준점수 입력란"
          required="required" type="text">
         </div>
          <div class="col-md-6">
          <label class="field-label-2" for="leetAPscore">언어이해 백분위</label>
          <input class="form-control" data-name="leetAPscore" id="leetAPscore" maxlength="256" name="leetAPscore" placeholder="언어이해 백분위 입력란"
          required="required" type="text">
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
          <label class="field-label-2" for="leetBscore">추리논증 표준점수</label>
          <input class="form-control" data-name="leetBscore" id="leetBscore" maxlength="256" name="leetBscore" placeholder="추리논증 표준점수 입력란"
          required="required" type="text">
        </div>
          <div class="col-md-6">
          <label class="field-label-2" for="leetBPscore">추리논증 백분위</label>
          <input class="form-control" data-name="leetBPscore" id="leetBPscore" maxlength="256" name="leetBPscore" placeholder="추리논증 백분위 입력란"
          required="required" type="text">
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">

              <label class="field-label-2" for="schoolScore">학부성적 원점수</label>
              <div>
                <div class="radio-button-field w-radio">
                  <input class="w-radio-input" data-name="radioSchool" id="40" name="radio" type="radio" value="4.0">
                  <label class="w-form-label" for="40">4.0</label>
                </div>
                <div class="radio-button-field w-radio">
                  <input class="w-radio-input" data-name="radioSchool" id="43" name="radio" type="radio" value="4.3">
                  <label class="w-form-label" for="43">4.3</label>
                </div>
                <div class="radio-button-field w-radio">
                  <input class="w-radio-input" checked="checked" data-name="radioSchool" id="45" name="radio" type="radio" value="4.5">
                  <label class="w-form-label" for="45">4.5</label>
                </div>
              </div>
              <input class="form-control" data-name="schoolScore" id="schoolScore" maxlength="256" name="schoolScore" placeholder="학부성적 원점수 입력란"
              required="required" type="text">

            </div>
            <div class="col-md-6">
              <label class="field-label-2" for="engScore">영어성적 원점수</label>
              <div>
                <div class="radio-button-field w-radio">
                  <input class="w-radio-input"checked="checked" data-name="radioEng" id="toeic" name="radioEng" type="radio" value="toeic">
                  <label class="w-form-label" for="toeic">TOEIC</label>
                </div>
                <div class="radio-button-field w-radio">
                  <input class="w-radio-input" data-name="radioEng" id="toefl" name="radioEng" type="radio" value="toefl">
                  <label class="w-form-label" for="toefl">TOEFL</label>
                </div>
                <div class="radio-button-field w-radio">
                  <input class="w-radio-input" data-name="radioEng" id="teps" name="radioEng" type="radio" value="teps">
                  <label class="w-form-label" for="teps">TEPS</label>
                </div>
              </div>
              <input class="form-control" data-name="engScore" id="engScore" maxlength="256" name="engScore" placeholder="영어성적 원점수 입력란"
              required="required" type="text">
              <input type="hidden" name="signState" value="">
            </div>
          </div>
          <br>
           <a class="btn btn-default btn-lg" href="leetConvertTable.html" onclick="window.open(this.href, '_blanck', 'width=600, height=700'); return false">2018 리트 변환표</a>

                <input type="submit" class=" btn btn-default btn-lg " value="확인" style="float: right;">
                <br><br>

        </form>

    </div>
    </div>
    <br><br>
    <div align = "center">
      <p><font size="6px" >made by hyeum <br>
      knholic@gmail.com</font></p>
    </div>
<br><br><br>
<div align="center">
  <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <!-- lawcalc.xyz-반응형 -->
  <ins class="adsbygoogle"
       style="display:block"
       data-ad-client="ca-pub-8511691406076432"
       data-ad-slot="7887483485"
       data-ad-format="auto"></ins>
  <script>
  (adsbygoogle = window.adsbygoogle || []).push({});
  </script>
</div>
  </body>
</html>
