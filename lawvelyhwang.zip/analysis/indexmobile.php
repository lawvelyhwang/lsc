

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="style_mobile.css?v=1">
<title></title>
<style type="text/css">
label{
  display: block;
  margin-bottom: 5px;
  font-weight: blod;
}
  .heading2{
      text-align: center;
  }
  .container-2{
    padding-top: 10px;
    padding-bottom: 10px;
    background-color: rgba(0,0,0,.11);
  }
  .field-label-6{
    padding-left: 10px;
    font-size: 16px;
  }
  .text-block{
    margin-top: 18px;
    text-align: center;
  }
  .f275{
        width: 275px;
  }
  .f301{
    width: 301px;
  }
  .form-control {
    display: block;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 5px;
    height: 30px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
    -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
         -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
  }
  .form-control:focus {
    border-color: #66afe9;
    outline: 0;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, .6);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, .6);
  }
  .form-control::-moz-placeholder {
    color: #999;
    opacity: 1;
  }
  .form-control:-ms-input-placeholder {
    color: #999;
  }
  .form-control::-webkit-input-placeholder {
    color: #999;
  }
  .form-control::-ms-expand {
    background-color: transparent;
    border: 0;
  }
  .btn {
    display: block;
    margin-left: auto;
    margin-right: 15px;
    margin-top: 15px;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: normal;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
        touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
       -moz-user-select: none;
        -ms-user-select: none;
            user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
  }
  .btn:focus,
  .btn:active:focus,
  .btn.active:focus,
  .btn.focus,
  .btn:active.focus,
  .btn.active.focus {
    outline: 5px auto -webkit-focus-ring-color;
    outline-offset: -2px;
  }
  .btn:hover,
  .btn:focus,
  .btn.focus {
    color: #333;
    text-decoration: none;
  }
  .btn:active,
  .btn.active {
    background-image: none;
    outline: 0;
    -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
            box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
  }
  .btn.disabled,
  .btn[disabled],
  fieldset[disabled] .btn {
    cursor: not-allowed;
    filter: alpha(opacity=65);
    -webkit-box-shadow: none;
            box-shadow: none;
    opacity: .65;
  }
  a.btn.disabled,
  fieldset[disabled] a.btn {
    pointer-events: none;
  }
  .btn-default {
    color: #333;
    background-color: #fff;
    border-color: #ccc;
  }
  .btn-default:focus,
  .btn-default.focus {
    color: #333;
    background-color: #e6e6e6;
    border-color: #8c8c8c;
  }
  .btn-default:hover {
    color: #333;
    background-color: #e6e6e6;
    border-color: #adadad;
  }
  .btn-default:active,
  .btn-default.active,
  .open > .dropdown-toggle.btn-default {
    color: #333;
    background-color: #e6e6e6;
    border-color: #adadad;
  }
  .btn-default:active:hover,
  .btn-default.active:hover,
  .open > .dropdown-toggle.btn-default:hover,
  .btn-default:active:focus,
  .btn-default.active:focus,
  .open > .dropdown-toggle.btn-default:focus,
  .btn-default:active.focus,
  .btn-default.active.focus,
  .open > .dropdown-toggle.btn-default.focus {
    color: #333;
    background-color: #d4d4d4;
    border-color: #8c8c8c;
  }
  .btn-default:active,
  .btn-default.active,
  .open > .dropdown-toggle.btn-default {
    background-image: none;
  }
  .btn-default.disabled:hover,
  .btn-default[disabled]:hover,
  fieldset[disabled] .btn-default:hover,
  .btn-default.disabled:focus,
  .btn-default[disabled]:focus,
  fieldset[disabled] .btn-default:focus,
  .btn-default.disabled.focus,
  .btn-default[disabled].focus,
  fieldset[disabled] .btn-default.focus {
    background-color: #fff;
    border-color: #ccc;
  }
  .btn-default .badge {
    color: #fff;
    background-color: #333;
  }

</style>
<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, width=device-width, height=device-height">

</head>
<body>
  <div align="center"><h1 class="heading-2">로스쿨 모의지원</h1></div>
  <div class="container-2 w-container">
    <div class="w-form">
      <form action="http://lawschoolcalc.000webhostapp.com/process.php" method="post">
        <label class="field-label-6">언어이해</label>
        <input class="form-control f275" data-name="leetAscore" id="leetAscore" maxlength="256" name="leetAscore" placeholder="언어이해 표준점수" required="required" type="text">
        <input class=" form-control f275" data-name="leetAPscore" id="leetAPscore" maxlength="256" name="leetAPscore" placeholder="언어이해 백분위" required="required" type="text">
        <label class="field-label-6">추리논증</label>
        <input class=" form-control f275" data-name="leetBscore" id="leetBscore" maxlength="256" name="leetBscore" placeholder="추리논증 표준점수" required="required" type="text">
        <input class=" form-control f275" data-name="leetBPscore" id="leetBPscore" maxlength="256" name="leetBPscore" placeholder="추리논증 백분위" required="required" type="text">
        <label class="field-label-6">학부성적</label>
        <select class=" form-control f301" data-name="radio" id="radio" name="radio">
          <option value="4.5">4.5</option>
          <option value="4.3">4.3</option>
          <option value="4.0">4.0</option>
        </select>
        <input class=" form-control f275" data-name="schoolScore" id="schoolScore" maxlength="256" name="schoolScore" placeholder="학부성적 원점수" required="required" type="text">
        <label class="field-label-6">어학성적</label>
        <select class=" form-control f301" data-name="radioEng" id="radioEng" name="radioEng">
          <option value="toeic">TOEIC</option>
          <option value="toefl">TOEFL</option>
          <option value="teps">TEPS</option>
        </select>
        <input class=" form-control f275" data-name="engScore" id="engScore" maxlength="256" name="engScore" placeholder="어학성적 원점수" required="required" type="text">
        <input type="submit" class="btn btn-default" value="확인">
      </form>
    </div>
  </div>
  <br>
  <div align = "center">
    made by hyeum <br>
    knholic@gmail.com
  </div>
<br><br><br>
<div align="center">
  <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- lawcalc.xyz-반응형 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8511691406076432"
     data-ad-slot="7887483485"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
</body>
</html>
