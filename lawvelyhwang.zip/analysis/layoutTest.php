<?php
$mobileKeyWords = ['iPhone', 'iPod', 'BlackBerry', 'Android', 'Windows CE', 'Windows CE;', 'LG', 'MOT', 'SAMSUNG', 'SonyEricsson', 'Mobile', 'Symbian', 'Opera Mobi', 'Opera Mini', 'IEmobile'];
for($i = 0; $i < count($mobileKeyWords); $i++)
{
if(strpos($_SERVER['HTTP_USER_AGENT'],$mobileKeyWords[$i]) == true)
 {
header('Location: http://lawschoolcalc.000webhostapp.com/indexmobile.php/');
exit;
 }
}
?>

<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>CSS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <meta name="google-signin-client_id" content="621886397966-713k1lgqlidrb6nbtbdcehm7lnoe8bmn.apps.googleusercontent.com">
    <script src="https://apis.google.com/js/platform.js" async defer>
    gapi.load('auth2', function(){gapi.auth2.init();});
    </script>
  </head>
  <body>
    <div id="jb-container">
      <header>
        <div id="jb-header">
          <div class="col-md-6">
          <h1>Road To Lawschool</h1>
          </div>

          <div class="g-signin2" data-onsuccess="onSignIn" id="signInBtn" align="right"></div>
          <script type="text/javascript">
          function onSignIn(googleUser) {
            document.getElementById('signInBtn').style.display="none";
            document.getElementById('signOutBtn').style.display="block";

          var profile = googleUser.getBasicProfile();
          console.log('ID: ' + profile.getId());
          console.log('Full Name: ' + profile.getName());
          console.log('Given Name: ' + profile.getGivenName());
          console.log('Family Name: ' + profile.getFamilyName());
          console.log('Image URL: ' + profile.getImageUrl());
          console.log('Email: ' + profile.getEmail());
          document.getElementById('userInfo').innerHTML = profile.getName();
          }

          </script>
          <a href="#" onclick="signOut();" class="btn btn-default" id="signOutBtn">Sign out</a>

          <script>
            document.getElementById('signOutBtn').style.display="none";

            function signOut() {
            document.getElementById('signOutBtn').style.display="none";
            document.getElementById('signInBtn').style.display="block";
            document.getElementById('userInfo').innerHTML = '';

            var auth2 = gapi.auth2.getAuthInstance();
            auth2.signOut().then(function () {
              console.log('User signed out.');

              });
            }


          </script>
          <p  id='userInfo'></p>
        </div>

      </header>
      <article>

        <div id="jb-content">

            <h1 class="heading">로스쿨 모의지원</h1><br>
          <div class="container">
            <div class="jumbotron">
              <form class="" action="process.php" method="post">
                <div class="row">
                  <div class="col-md-6">
                <label class="field-label-2" for="leetAscore">언어이해 표준점수</label>
                <input class="form-control" data-name="leetAscore" id="leetAscore" maxlength="256" name="leetAscore" placeholder="언어이해 표준점수 입력란"
                required="required" type="text">
               </div>
                <div class="col-md-6">
                <label class="field-label-2" for="leetAPscore">언어이해 백분위</label>
                <input class="form-control" data-name="leetAPscore" id="leetAPscore" maxlength="256" name="leetAPscore" placeholder="언어이해 백분위 입력란"
                required="required" type="text">
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                <label class="field-label-2" for="leetBscore">추리논증 표준점수</label>
                <input class="form-control" data-name="leetBscore" id="leetBscore" maxlength="256" name="leetBscore" placeholder="추리논증 표준점수 입력란"
                required="required" type="text">
              </div>
                <div class="col-md-6">
                <label class="field-label-2" for="leetBPscore">추리논증 백분위</label>
                <input class="form-control" data-name="leetBPscore" id="leetBPscore" maxlength="256" name="leetBPscore" placeholder="추리논증 백분위 입력란"
                required="required" type="text">
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">

                    <label class="field-label-2" for="schoolScore">학부성적 원점수</label>
                    <div>
                      <div class="radio-button-field w-radio">
                        <input class="w-radio-input" data-name="radioSchool" id="40" name="radio" type="radio" value="4.0">
                        <label class="w-form-label" for="40">4.0</label>
                      </div>
                      <div class="radio-button-field w-radio">
                        <input class="w-radio-input" data-name="radioSchool" id="43" name="radio" type="radio" value="4.3">
                        <label class="w-form-label" for="43">4.3</label>
                      </div>
                      <div class="radio-button-field w-radio">
                        <input class="w-radio-input" checked="checked" data-name="radioSchool" id="45" name="radio" type="radio" value="4.5">
                        <label class="w-form-label" for="45">4.5</label>
                      </div>
                    </div>
                    <input class="form-control" data-name="schoolScore" id="schoolScore" maxlength="256" name="schoolScore" placeholder="학부성적 원점수 입력란"
                    required="required" type="text">

                  </div>
                  <div class="col-md-6">
                    <label class="field-label-2" for="engScore">영어성적 원점수</label>
                    <div>
                      <div class="radio-button-field w-radio">
                        <input class="w-radio-input"checked="checked" data-name="radioEng" id="toeic" name="radioEng" type="radio" value="toeic">
                        <label class="w-form-label" for="toeic">TOEIC</label>
                      </div>
                      <div class="radio-button-field w-radio">
                        <input class="w-radio-input" data-name="radioEng" id="toefl" name="radioEng" type="radio" value="toefl">
                        <label class="w-form-label" for="toefl">TOEFL</label>
                      </div>
                      <div class="radio-button-field w-radio">
                        <input class="w-radio-input" data-name="radioEng" id="teps" name="radioEng" type="radio" value="teps">
                        <label class="w-form-label" for="teps">TEPS</label>
                      </div>
                    </div>
                    <input class="form-control" data-name="engScore" id="engScore" maxlength="256" name="engScore" placeholder="영어성적 원점수 입력란"
                    required="required" type="text">

                  </div>
                </div>
                <br>
                      <input type="submit" class=" btn btn-default btn-lg " value="확인" style="float: right;">
                      <br><br>

              </form>


          </div>
          </div>
        </div>
      </article>
      <nav>
        <div id="jb-sidebar">
          <h2>Sidebar</h2>
          <ul>
            <li>Lorem</li>
            <li>Ipsum</li>
            <li>Dolor</li>
          </ul>
        </div>
      </nav>
      <footer>
      <div id="jb-footer">
        <p>Made by hyeum<br>knholic@gmail.com</p>
      </div>
    </footer>
    </div>
  </body>
</html>
