<?php
  include("../head.php");
?>



  <?php
  error_reporting(0);
  //    error_reporting(E_ALL);
  //    ini_set("display_errors",1);
  $start_time = array_sum(explode(' ', microtime()));

  $leetApure = $_POST['leetApure'];
  $leetBpure = $_POST['leetBpure'];
  $leetAscore = $_POST['leetAscore'];
  $leetAPscore = $_POST['leetAPscore'];
  $leetBscore = $_POST['leetBscore'];
  $leetBPscore = $_POST['leetBPscore'];
  $schoolScoreType = $_POST['radio'];
  $schoolScore = $_POST['schoolScore'];
  $engScoreType = $_POST['radioEng'];
  $engScore = $_POST['engScore'];
  $scoreArray = [$leetAscore,$leetAPscore, $leetBscore,$leetBPscore, $schoolScoreType, $schoolScore,$engScoreType, $engScore, $leetApure, $leetBpure];
  $sql = "insert into usertable (id, leetAscore, leetAPscore, leetBscore, leetBPscore, gpaindex, gpascore, engindex, engscore)
          values('{$_SESSION['login_user']}', {$leetAscore}, {$leetAPscore}, {$leetBscore}, {$leetBPscore}, {$schoolScoreType}, {$schoolScore}, '{$engScoreType}', {$engScore})";
  $result = mysqli_query($db,$sql);

  require_once 'lib.php';
  set_user($scoreArray); //usertable 에 사용자 정보 입력

  $school1 = new kwu($scoreArray);
  $school2 = new kku($scoreArray);
  $school3 = new knu($scoreArray);
  $school4 = new khu($scoreArray);
  $school5 = new kru($scoreArray);
  $school6 = new dau($scoreArray);
  $school7 = new bsu($scoreArray);
  $school8 = new sgu($scoreArray);
  $school9 = new snu($scoreArray);
  $school10 = new uos($scoreArray);
  $school11 = new skku($scoreArray);
  $school12 = new aju($scoreArray);
  $school13 = new ysu($scoreArray);
  $school14 = new ynu($scoreArray);
  $school15 = new wgu($scoreArray);
  $school16 = new ehu($scoreArray);
  $school17 = new ihu($scoreArray);
  $school18 = new jnu($scoreArray);
  $school19 = new jbu($scoreArray);
  $school20 = new jju($scoreArray);
  $school21 = new jau($scoreArray);
  $school22 = new cnu($scoreArray);
  $school23 = new cbu($scoreArray);
  $school24 = new hufs($scoreArray);
  $school25 = new hyu($scoreArray);

  $school = [$school1, $school2, $school3, $school4, $school5,
  $school6, $school7, $school8, $school9, $school10, $school11,
  $school12,$school13, $school14, $school15, $school16, $school17,
  $school18, $school19, $school20, $school21, $school22, $school23, $school24, $school25];

  $resultup = recommend($scoreArray,1);
  $resultdown = recommend($scoreArray,2);


  for($i=0; $i<count($school); $i++){
    $school[$i]->get_convertedScores();
  }


  $end_time = array_sum(explode(' ', microtime()));

  //      echo "TIME : ". ( $end_time - $start_time );


  ?>

  <h1 class="heading"  align="center">로스쿨 모의지원</h1><br>
  <div class="container">
    <div class="jumbotron">
      <div class="panel panel-default">
        <!-- Default panel contents -->


        <?php
        $name = $_POST['name'];
        $age = $_POST['age'];
        $schoolmain = $_POST['school'];
        $major = $_POST['major'];
        $schoolsub = $_POST['schoolsub'];

        echo "<br>언어 표점 : ".$leetAscore." | 추리 표점 : ".$leetBscore." | GPA : ".$schoolScore." / ".$schoolScoreType." | 영어점수 : ".$engScore." / ".$engScoreType."<br><br>";
        for($i = 1; $i<=4; $i++){
          $updown;
          if($i <3){
            $result = $resultup;
            $updown = "상향지원";
          }else{
            $result = $resultdown;
            $updown = "하향지원";
          }
          $row = mysqli_fetch_assoc($result);
          $convertedLeet = round($school[$row['schoolnumber']-1]->convertedScore[0],2);
          $convertedGpa = round($school[$row['schoolnumber']-1]->convertedScore[1],2);
          $convertedEng = $school[$row['schoolnumber']-1]->convertedScore[2];
          $resultRate = get_table_etc("applicationrates", $row['schoolnumber']);
          $rowRate = mysqli_fetch_assoc($resultRate);
          $resultAvg = get_table_etc("avg2017table", $row['schoolnumber']);
          $rowAvg = mysqli_fetch_assoc($resultAvg);

          $sumValueRate = $rowRate['leet']+$rowRate['eng']+$rowRate['gpa'];
          $sumValue = $convertedLeet + $convertedEng + $convertedGpa;
          $sumAvg = $rowAvg['leet'] + $rowAvg['gpa'] + $rowAvg['eng'];
          echo "
          <div class=\"panel-heading\">{$updown}</div>
          <table class=\"table\">
            <thead>
              <tr>
                <th width=\"18%\">추천순위</th>
                <th width=\"18%\">구분</th>
                <th width=\"16%\">리트</th>
                <th width=\"16%\">학점</th>
                <th width=\"16%\">영어</th>
                <th width=\"16%\">합계</th>
              </tr>

            </thead><tbody><tr >
              <td rowspan=\"4\"  width=\"18%\"><br>{$row['schoolname']}</td>
              <td width=\"18%\">변환점수</td>
              <td width=\"16%\">{$convertedLeet}</td>
              <td width=\"16%\">{$convertedGpa}</td>
              <td width=\"16%\">{$convertedEng}</td>
              <td width=\"16%\">{$sumValue}</td>
            </tr>
            <tr>
              <td width=\"18%\">최대점수</td>
              <td width=\"16%\">{$rowRate['leet']}</td>
              <td width=\"16%\">{$rowRate['gpa']}</td>
              <td width=\"16%\">";
                if($rowRate['eng']== 0){
                  echo "pass";
                }else{
                  echo $rowRate['eng'];
                }
                echo "</td>
                <td width=\"16%\">{$sumValueRate}</td>
              </tr>
              <tr>
                <td width=\"18%\">평균변환점수</td>
                <td width=\"16%\">{$rowAvg['leet']}</td>
                <td width=\"16%\">{$rowAvg['gpa']}</td>
                <td width=\"16%\">";
                  if($i == 5){
                    echo 99.7;
                  }elseif($rowAvg['eng']== 0){
                    echo "pass";
                  }else{
                    echo $rowAvg['eng'];
                  }
                  echo "</td>
                  <td width=\"16%\">{$sumAvg}</td>
                </tr>

                <tr>";
                  $percentleet = round($convertedLeet/$rowAvg['leet'],4)*100;
                  $percentgpa = round($convertedGpa/$rowAvg['gpa'],4)*100;
                  $percenteng = round($convertedEng/$rowAvg['eng'],4)*100;
                  $percentsum = round($sumValue/$sumAvg,4)*100;

                  echo "<td width=\"18%\">본인 / 평균</td> <td width=\"16%\"";
                  if($percentleet <= 90){
                    echo " style= \"color:#ff0000; font-weight:bold;\"";
                  }elseif($percentleet >= 110){
                    echo " style= \"color:#0000ff;\"";
                  }
                  echo  ">{$percentleet}%</td>
                  <td width=\"16%\"";

                  if($percentgpa <= 90){
                    echo " style= \"color:#ff0000; font-weight:bold;\"";
                  }elseif($percentgpa >= 110){
                    echo " style= \"color:#0000ff;\"";
                  }
                  echo ">{$percentgpa}%</td>
                  <td width=\"16%\"";

                  if($percenteng <= 90){
                    if($percenteng != 0){
                      echo " style= \"color:#ff0000; font-weight:bold;\"";
                      echo ">{$percenteng}%";}else{
                        echo ">-";
                      }

                    }elseif($percenteng >= 110){
                      echo " style= \"color:#0000ff;\"";
                      echo ">{$percenteng}%";
                    }else{
                      echo ">{$percenteng}%";
                    }
                    echo "</td><td width=\"16%\"";

                    if($percentsum <= 90){
                      echo " style= \"color:#ff0000; font-weight:bold;\"";
                    }elseif($percentsum >= 110){
                      echo " style= \"color:#0000ff;\"";
                    }
                    echo ">{$percentsum}%</td>
                  </tr>

                </tbody>
              </table>";
            }


            ?>
          </div>
          <form name="userform" method="post" action="result.php">
            <?php
            echo "<input type=\"hidden\" name=\"leetAscore\" value=\"{$school[0]->scoreArray[0]}\">";
            echo "<input type=\"hidden\" name=\"leetAPscore\" value=\"{$school[0]->scoreArray[1]}\">";
            echo "<input type=\"hidden\" name=\"leetBscore\" value=\"{$school[0]->scoreArray[2]}\">";
            echo "<input type=\"hidden\" name=\"leetBPscore\" value=\"{$school[0]->scoreArray[3]}\">";
            echo "<input type=\"hidden\" name=\"radio\" value=\"{$school[0]->scoreArray[4]}\">";
            echo "<input type=\"hidden\" name=\"schoolScore\" value=\"{$school[0]->scoreArray[5]}\">";
            echo "<input type=\"hidden\" name=\"radioEng\" value=\"{$school[0]->scoreArray[6]}\">";
            echo "<input type=\"hidden\" name=\"engScore\" value=\"{$school[0]->scoreArray[7]}\">";
            echo "<input type=\"hidden\" name=\"leetApure\" value=\"{$school[0]->scoreArray[8]}\">";
            echo "<input type=\"hidden\" name=\"leetBpure\" value=\"{$school[0]->scoreArray[9]}\">";
            ?>
            <br>

            <input type="submit" class=" btn btn-default btn-lg " value="전체 학교 보기" style="float: right;">
          </form>
          <br><br><br><br>
          <script type="text/javascript">
            google.charts.load('current', {'packages':['corechart', 'controls']});
            google.charts.setOnLoadCallback(drawDashboard);

            function drawDashboard() {

              // Everything is loaded. Assemble your dashboard...
              var dashboard = new google.visualization.Dashboard(document.getElementById('dashboard_div'));
              var dataTable = new google.visualization.DataTable();
              dataTable.addColumn('string', 'schoolName');
              dataTable.addColumn('number', '25%');
              dataTable.addColumn('number', '50%');
              dataTable.addColumn('number', 'avg');
              dataTable.addColumn('number', '75%');
              dataTable.addColumn('number', '나의 점수');

              dataTable.addRows([
              ['강원대', 117, 111.2, 111.9, 107.4, null],
              ['건국대', 120.7, 118.7, 121.45, 126.5, null],
              ['경북대', 114.89, 111.01, 110.27, 105.51, null],
              ['경희대', 117, 113, 109, 101.5, null],
              ['고려대', 130.2, 126.4, 126.4, 124.5, null],
              ['동아대', 105.4, 99.7, 100.1, 94.1, null],
              ['부산대', 117, 111.4, 111.2, 110.5, null],
              ['서강대', 118.9, 118.9, 116.7, 105.4, null],
              ['서울대', 139.3, 135.4, 134.2, 131.5, null],
              ['시립대', 124.5, 120.6, 119.55, 113.2, null],
              ['성균관대', 130.2, 126.4, 125.5, 120.7, null],
              ['아주대', 120.7, 122.6, 111.5, 103.5, null]
              ], true);
              var leetScore = <?php echo $school[0]->scoreArray[0] + $school[0]->scoreArray[2]; ?>;
              var gpaScore = <?php
              $convertedGpa = round($school[8]->convertedScore[1],2) * ($school[0]->scoreArray[0] +  $school[0]->scoreArray[2])/100;
              echo $convertedGpa; ?>;
              var tootip = " 나의 위치 <br> leet : "+leetScore;
              dataTable.addRows([
              ['Leet', null, null, null, null, leetScore],
              ['연세대', 128, 125, 126, 121, null],
              ['영남대', 109.3, 99.7, 100.92, 93.9, null],
              ['원광대', 103.6, 101.6, 99.7, 95.9, null],
              ['이화여대', 112.5, 128.3, 116, 111.1, null],
              ['인하대', 116.8, 113, 112.7, 109.3, null],
              ['전남대', 111.3, 105.4, 108.48, 108.48, null],
              ['전북대', null, null, 110.86, null, null],
              ['제주대', 101.7, 97.8, 98.4, 99.7, null],
              ['중앙대', 114.91, 114.55, 114.18, 114.18, null],
              ['충남대', 118.9, 118.9, 112.08, 103.5, null],
              ['충북대', 111.17, 107.46, 107.76, 105.29, null],
              ['한국외대', 122.5, 118.8, 119, 114.9, null],
              ['한양대', 125.86, 120.88, 121.54, 116.87, null]
              ], true);

              var dataTable1 = new google.visualization.DataTable();
              dataTable1.addColumn('string', 'schoolName');
              dataTable1.addColumn('number', '25%');
              dataTable1.addColumn('number', '50%');
              dataTable1.addColumn('number', 'avg');
              dataTable1.addColumn('number', '75%');
              dataTable1.addColumn('number', '나의 점수');
              dataTable1.addRows([
              ['강원대', 94.2, 90.7, 89.99, 87.44, null],
              ['건국대', 93, 93.6, 90.6, 90, null],
              ['경북대', 94.6, 91.71, 91.31, 88.37, null],
              ['경희대', 91, 86.5, 86.5, 84, null],
              ['고려대', 97, 95, 95, 94, null],
              ['동아대', 94.5, 91.4, 90.3, 87.8, null],
              ['부산대', 94.95, 92.7, 92.25, 90.6, null],
              ['서강대', 96.6, 93.3, 91.4, 89.6, null],
              ['서울대', 97.6, 96.7, 96.52, 95.6, null],
              ['시립대', 94.8, 92.5, 92.37, 89.7, null],
              ['성균관대', 94.7, 93.3, 92.7, 91.2, null],
              ['아주대', 83.5, 83.2, 89.4, 84.8, null]
            ], true);
              var leetScore = <?php echo ($school[0]->scoreArray[0] + $school[0]->scoreArray[2]); ?>;
              var gpaScore = <?php
              $convertedGpa = round($school[8]->convertedScore[1],2);
              echo $convertedGpa; ?>;
              var tootip = " 나의 위치 <br> gpa : "+gpaScore;
              dataTable1.addRows([
              ['Gpa', null, null, null, null, gpaScore],
              ['연세대', 96, 95.4, 95.2, 94.4, null],
              ['영남대', 91.7, 87.9, 88.4, 85.3, null],
              ['원광대', 93.7, 91.3, 89.4, 85.7, null],
              ['이화여대', 97.4, 91.6, 95.5, 94.4, null],
              ['인하대', 95.5, 94.1, 93.8, 92.3, null],
              ['전남대', 95.1, 93, 92.49, 90.88, null],
              ['전북대', null, null, 92.5, null, null],
              ['제주대', 95.6, 95.5, 94, 94.9, null],
              ['중앙대', 97, 96, 95, 92, null],
              ['충남대', 91.2, 93.41, 93.7, 92.3, null],
              ['충북대', 95, 94, 94, 91, null],
              ['한국외대', 96.4, 94.2, 93.1, 90.5, null],
              ['한양대', 96.7, 95.3, 95.1, 93.9, null]
              ], true);

              var dataTable2 = new google.visualization.DataTable();
              dataTable2.addColumn('string', 'schoolName');
              dataTable2.addColumn('number', '25%');
              dataTable2.addColumn('number', '50%');
              dataTable2.addColumn('number', 'avg');
              dataTable2.addColumn('number', '75%');
              dataTable2.addColumn('number', '나의 점수')
              dataTable2.addRows([
              ['강원대', 110.21, 100.86, 100.7, 93.91, null],
              ['건국대', 112.25, 111.1, 110.03, 113.85, null],
              ['경북대', 108.69, 101.81, 100.69, 93.24, null],
              ['경희대', 106.47, 97.75, 94.29, 85.26, null],
              ['고려대', 126.29, 120.08, 120.08, 117.03, null],
              ['동아대', 99.6, 91.13, 90.39, 82.62, null],
              ['부산대', 111.09, 103.27, 103.23, 100.11, null],
              ['서강대', 114.86, 110.93, 105.64, 94.44, null],
              ['서울대', 135.96, 130.93, 127.79, 125.71, null],
              ['시립대', 118.03, 111.56, 110.43, 101.54, null],
              ['성균관대', 123.3, 117.93, 112.86, 110.08, null],
              ['아주대', 100.78, 102, 99.86, 87.77, null]

              ], true);

              var gpaScore = <?php
              $convertedGpa = round($school[8]->convertedScore[1] * ( $school[0]->scoreArray[0] +  $school[0]->scoreArray[2])/100,2);
              echo $convertedGpa; ?>;
              var tootip = " 나의 위치 <br> 추천점수 : "+gpaScore;
              dataTable2.addRows([
              ['추천지수', null, null, null, null, gpaScore],
              ['연세대', 122.88, 119.25, 119.41, 114.22, null],
              ['영남대', 100.23, 87.64, 89.21, 80.1, null],
              ['원광대', 97.07, 92.76, 89.13, 82.19, null],
              ['이화여대', 109.58, 117.52, 106.93, 104.88, null],
              ['인하대', 111.54, 106.33, 104.26, 100.88, null],
              ['전남대', 105.85, 98.02, 100.33, 98.59, null],
              ['전북대', null, null, 102.55, null, null],
              ['제주대', 97.23, 93.4, 92.7, 94.62, null],
              ['중앙대', 111.46, 109.96, 108.47, 105.05, null],
              ['충남대', 108.44, 111.06, 101.73, 95.53, null],
              ['충북대', 105.62, 101.01, 101.30, 95.81, null],
              ['한국외대', 118.09, 111.91, 106.48, 103.98, null],
              ['한양대', 121.71, 115.2, 115.59, 109.74, null]
              ], true);

              var data = [];
              data[0] = dataTable;
              data[1] = dataTable1;
              data[2] = dataTable2;



              var current = 0;
              var columnsTable = new google.visualization.DataTable();
              columnsTable.addColumn('number', 'colIndex');
              columnsTable.addColumn('string', 'colLabel');
              var initState= {selectedValues: []};
              // put the columns into this data table (skip column 0)
              for (var i = 1; i < data[current].getNumberOfColumns(); i++) {
                columnsTable.addRow([i, data[current].getColumnLabel(i)]);
                // you can comment out this next line if you want to have a default selection other than the whole list
                initState.selectedValues.push(data[current].getColumnLabel(i));
              }

              // Create and draw the visualization.
              var columnFilter = new google.visualization.ControlWrapper({
                controlType: 'CategoryFilter',
                containerId: 'colFilter_div',
                dataTable: columnsTable,

                options: {
                  filterColumnLabel: 'colLabel',
                  ui: {
                    label: '',
                    caption: '범주 선택',
                    allowTyping: false,
                    allowMultiple: true,
                    allowNone: false
                  }
                },
                state: initState
              });

              var options = {
                hAxis: {
                  slantedText: true,
                  slantedTextAngle: 90
                },
                titleTextStyle: {
                  fontSize: 18
                },
                crosshair: {
                  trigger: 'both',
                  orientation: 'horizontal'},
                  series: {
                    2: {pointSize: 15, pointShape: { type: 'star', sides: 5, dent: 0.5 } },

                    4: {pointSize: 20, pointShape: { type: 'star', sides: 5, dent: 0.5 } },
                  }
                };

                var chart = new google.visualization.ChartWrapper({
                  chartType: 'ScatterChart',
                  containerId: 'chart_div'
                });
                chart.setOptions(options);

                function setChartView () {
                  var state = columnFilter.getState();
                  var row;
                  var view = {
                    columns: [0]
                  };

                  for (var i = 0; i < state.selectedValues.length; i++) {
                    row = columnsTable.getFilteredRows([{column: 1, value: state.selectedValues[i]}])[0];
                    view.columns.push(columnsTable.getValue(row, 0));
                  }
                  // sort the indices into their original order
                  view.columns.sort(function (a, b) {
                    return (a - b);
                  });
                  chart.setView(view);
                  chart.setDataTable(data[current]);
                  chart.draw();
                }
                google.visualization.events.addListener(columnFilter, 'statechange', setChartView);

                var button1 = document.getElementById('b1');
                var button2 = document.getElementById('b2');
                var button3 = document.getElementById('b3');
                function drawDashboard() {
                  var standard;
                  if(current ==0){
                    standard = "leet";
                  }else if (current==1) {
                    standard = "gpa";
                  }else {
                    standard = "추천지수";
                  }
                  options['title'] = '정량 - 나의 위치 ( ' + standard  +' 기준 )';
                  chart.setDataTable(data[current]);
                  chart.draw();
                }
                drawDashboard();

                button1.onclick = function() {
                  current = 0;
                  drawDashboard();
                }
                button2.onclick = function() {
                  current = 1;
                  drawDashboard();
                }
                button3.onclick = function() {
                  current = 2;
                  drawDashboard();
                }


                setChartView();
                columnFilter.draw();
              }


            </script>
            <style type="text/css">
              .google-visualization-controls-categoryfilter li {
                border: 1px solid #cccccc !important;
                background-color: #ffffff !important;
                -moz-border-radius: 2px;
                border-radius: 2px;
                padding: 0.2em;
                margin: 0.2em 0
              }

              .google-visualization-controls-categoryfilter li .goog-link-button {
                font-size: 0.9em;
                font-weight: bold;
                padding: 0 0.4em 0 0.2em;
                color: #000000 !important;
                cursor: pointer
              }
              .goog-menu-button-outer-box, .goog-menu-button-inner-box {
                border-style: solid;
                border-color: #ccc !important;
                vertical-align: top;}

                .goog-menu-button {
                  background: white;
                  border: 0;
                  color: #000;
                  cursor: pointer;
                  list-style: none;
                  margin: 2px;
                  outline: none;
                  padding: 0;
                  text-decoration: none;
                  vertical-align: middle;
                }
              </style>

              <div class="row">
                <div class="col-md-12">
                  <div id="dashboard_div" align = "center">
                    <!--Divs that will hold each control and chart-->
                    <div id="colFilter_div"><br></div><br>
                    <div id="chart_div" style=" height: 700px;"></div>

                  </div>
                </div>
              </div>

              <br><br><div align="center">
                <div class="btn-group btn-group-lg" role="group" aria-label="Large button group">
                  <button id = 'b1' type="button" class="btn btn-default">Leet 기준</button>
                  <button id = 'b2' type="button" class="btn btn-default">Gpa 기준</button>
                  <button id = 'b3' type="button" class="btn btn-default">추천지수 기준</button>
                </div>
              </div><br><br>
              </div>
      </div>
      <br><br><br>
      <div align = "center">
        <p style="color:rgba(0,0,0,.38)"><font size="13px" >made by hyeum <br>
          knholic@gmail.com</font></p>
        </div>
        <br><br><br>

        </div>
        <?php
          include("../foot.php");
         ?>
