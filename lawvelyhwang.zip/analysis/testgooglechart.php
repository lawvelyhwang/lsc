<html>
  <head>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawChart);
function drawChart() {
 var data1 = google.visualization.arrayToDataTable([
   ['Mon', 20, 28, 38, 45],
   ['Tue', 31, 38, 55, 66],
   ['Wed', 50, 55, 77, 80]
   // Treat first row as data as well.
 ], true);

 var data2 = google.visualization.arrayToDataTable([
   ['Mon', 23, 23, 39, 42],
   ['Tue', 34, 34, 59, 64],
   ['Wed', 55, 52, 79, 80]
   // Treat first row as data as well.
 ], true);

 // Create and populate the data tables.
 var data = [];
 data[0] = data1;
 data[1] = data2;

 var options = {
   legend:'none'
 };

 var current = 0;
 var chart = new google.visualization.CandlestickChart(document.getElementById('chart_div'));
 var button = document.getElementById('b1');

 function drawChart() {
   // Disabling the button while the chart is drawing.
   button.disabled = true;
   google.visualization.events.addListener(chart, 'ready',
       function() {
         button.disabled = false;
         button.value = 'Switch to ' + (current ? 'Test A' : 'Test B');
       });
   options['title'] = 'Monthly ' + (current ? 'Test A' : 'Test B') + ' Production by Country';

   chart.draw(data[current], options);
 }
 drawChart();

 button.onclick = function() {
   current = 1 - current;
   drawChart();
 }

}
    </script>
  </head>
  <body>
    <div id="chart_div" style="width: 900px; height: 500px;"></div>
    <input type="button" value="Next day" id="b1" />
  </body>
</html>
