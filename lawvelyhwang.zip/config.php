<?php
   define('DB_SERVER', '14.138.155.33');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', 'Trust0925');
   define('DB_DATABASE', 'lawvelyhwang');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
