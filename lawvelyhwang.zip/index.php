<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="bootstrap.min.css">

    <title>러블리 황변</title>
  </head>
  <body>
    <header>
    <div class="" align="center">
      <img src="./logo.png" style="width: 50%">
    </div>
  </header>
  <div class="" align="center" >

    <table class="table" style="width: 30%">
      <form class="" action="./loginCheck.php" method="post">
      <tr>
        <td><label for="">id : </label></td>
        <td><input type="text" name="id" style="width: 100%"></td>
      </tr>
      <tr>
        <td><label for="">password : </label></td>
        <td><input type="password" name="password" style="width: 100%"></td>
      </tr>
      <tr>
<td colspan="2"></td>
      </tr>
      <tr>
        <td colspan="2" align="center">
          <input class="btn btn-default" type="submit" name="login" value="log In" style="width: 82px; font-weight: bold;">
          <a class="btn btn-default" href="./signin.php" style="margin-left: 30px;width: 82px; font-weight: bold;">sign In</a>

        </td>
      </tr>
      <tr>
        <td colspan="2" align="center">
        </td>
      </tr>

    </form>
    </table>

  </div>

  </body>
</html>
