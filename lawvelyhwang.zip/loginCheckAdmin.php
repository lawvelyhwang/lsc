
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <?php
    include("config.php");

    if(!isset($_POST['id']) || !isset($_POST['password'])) exit;
    $user_id = $_POST['id'];
    $user_pw = $_POST['password'];
    $target_url = "adminmain.php";

    if($_POST['id']=='kalitsma' && $_POST['password']=='pass0912'){
      session_start();
      $_SESSION['login_user'] = $user_id;
      header("Location: {$target_url}");
    }elseif($_POST['id']=='cesag' && $_POST['password']=='pass7375'){
      session_start();
      $_SESSION['login_user'] = $user_id;
      header("Location: {$target_url}");
    }else{
      $url = "admin.php";
      header("location: {$url}");
    }


    ?>

  </body>
</html>
