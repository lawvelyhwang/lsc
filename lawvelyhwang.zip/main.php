
    <?php
    include("head.php");

    ?>
    <style media="screen">
      .jumbotron{
        width: 80%;
        margin-right: auto;
        margin-left: auto;
      }
      tr{
        height: 37px;
      }
      .a-class{text-decoration:none; color:#000000;}
      .a-class:hover{color:#ff0000;} /* nav tag */
      .nav-ul{padding-top:10px;} /* 상단 여백 10px */
      .nav-ul-li { display:inline; /* 세로나열을 가로나열로 변경 */
        border-left:1px solid #999; /* 각 메뉴의 왼쪽에 "|" 표시(분류 표시) */
        font:12px Dotum; /* 폰트 설정 - 12px의 돋움체 굵은 글씨로 표시 */
        padding:0 10px; /* 각 메뉴 간격 */ }
        .active{
          font: bold 12px Dotum;;
        }
        .nav-ul-li:first-child{border-left:none;}
        .btn-primary{
          background-color: #fdf8d6 !important;
          border-color: #ccc !important;
          color: black;
        }

    </style>
    <div class="" align="center">
      <h2>면접, 자소서 수업 커리큘럼</h2>
      <br>
          <div class="btn-group" role="group" aria-label="First group">


        <?php
          if($_GET['cal']==1){
            echo
            "<a class=\"btn btn-primary\" href=\"?cal=1\">원서접수 전</a>
            <a  class=\"btn btn-default\" href=\"?cal=2\">원서접수 후</a>";
            $sql = "select * from curriculum_month1";
          }elseif($_GET['cal']==2){
            echo
            "<a class=\"btn btn-default\" href=\"?cal=1\">원서접수 전</a>
            <a  class=\"btn btn-primary\" href=\"?cal=2\">원서접수 후</a>";
            $sql = "select * from curriculum_month2";
          }else{
            echo
            "<a class=\"btn btn-default\" href=\"?cal=1\">원서접수 전</a>
            <a  class=\"btn btn-primary\" href=\"?cal=2\">원서접수 후</a>";
            $sql = "select * from curriculum_month2";
          }

          $result = mysqli_query($db,$sql);
         ?>

       </div>
    </div>
    <div class="">
      <br>
      <div class="container">
        <table class="table">
          <tr>
            <td style="width: 12.5%; text-align: center; font-size: 17px;">시간</td>
            <td style="width: 12.5%; text-align: center; font-size: 17px;">월</td>
            <td style="width: 12.5%; text-align: center; font-size: 17px; ">화</td>
            <td style="width: 12.5%; text-align: center; font-size: 17px;">수</td>
            <td style="width: 12.5%; text-align: center; font-size: 17px;">목</td>
            <td style="width: 12.5%; text-align: center;font-size: 17px;">금</td>
            <td style="width: 12.5%; text-align: center;font-size: 17px;">토</td>
            <td style="width: 12.5%; text-align: center;font-size: 17px;">일</td>

          </tr>

    <?php
        while($row = mysqli_fetch_assoc($result)){
          echo "<tr>";
          $colorRow;
          if($_GET['cal']==1){
            $colorRow = 3;
          }else{
            $colorRow=4;
          }
          if($row['index']%$colorRow==1){
            echo "<td class=\"is-visible\" style=\"text-align: center;\">"."</td>";
            echo "<td class=\"is-visible\" style=\"text-align: center;\">".$row['mon']."</td>";
            echo "<td class=\"is-visible\" style=\"text-align: center;\">".$row['tue']."</td>";
            echo "<td class=\"is-visible\" style=\"text-align: center;\">".$row['wed']."</td>";
            echo "<td class=\"is-visible\" style=\"text-align: center;\">".$row['thu']."</td>";
            echo "<td class=\"is-visible\" style=\"text-align: center;\">".$row['fri']."</td>";
            echo "<td class=\"is-visible\" style=\"text-align: center;\">".$row['sat']."</td>";
            echo "<td class=\"is-visible\" style=\"text-align: center;\">".$row['sun']."</td>";
          }else{
            if($row['tue']=='원서 접수 기간'){
              echo "<td style=\"text-align: center;\">"."오전"."</td>";
              echo "<td style=\"text-align: center;\">".$row['mon']."</td>";
              echo "<td colspan=\"4\" style=\"text-align: center;\">".$row['tue']."</td>";
              echo "<td style=\"text-align: center;\">".$row['sat']."</td>";
              echo "<td style=\"text-align: center;\">".$row['sun']."</td>";
            }else{
              $timeRow;
              switch ($row['index']%$colorRow) {
                case 2:
                $timeRow = "오전";
                break;
                case '0':
                $timeRow = "오후";
                break;
                case '3':
                $timeRow = "중간";
                break;
              }
              if(substr($row['sat'],-3)=="일"){
                $timeRow="";
              }
              echo "<td style=\"text-align: center;\">".$timeRow."</td>";
              echo "<td style=\"text-align: center;\">".$row['mon']."</td>";
              echo "<td style=\"text-align: center;\">".$row['tue']."</td>";
              echo "<td style=\"text-align: center;\">".$row['wed']."</td>";
              echo "<td style=\"text-align: center;\">".$row['thu']."</td>";
              echo "<td style=\"text-align: center;\">".$row['fri']."</td>";
              echo "<td style=\"text-align: center;\">".$row['sat']."</td>";
              echo "<td style=\"text-align: center;\">".$row['sun']."</td>";
            }

          }
          echo "</tr>";
        }
        echo "</table>";
    ?>
      </div>
    </div>

    <?php
    include("foot.php");
     ?>
