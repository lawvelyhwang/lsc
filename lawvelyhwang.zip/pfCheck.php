<?php
session_start();
  include("config.php");
  $sql = "update userprogress set w{$_GET['nowW']}tf = 'true' where id = '{$_GET['id']}'";
  $result = mysqli_query($db, $sql);
  $sql = "select * from userprogress where id = '{$_GET['id']}'";
  $result = mysqli_query($db, $sql);
  $row = mysqli_fetch_assoc($result);
  $nowWValue = 1;
  function nowWChanger(){
    global $row;
    if($row['w1tf'] == "true") {
      if($row['w2tf'] == "true"){
        if($row['w3tf'] == "true"){
          if($row['w4tf'] == "true"){
            if($row['w5tf'] == "true"){
              return 6;
            }
            return 5;
          }
          return 4;
        }
        return 3;
      }
      return 2;
    }
  }

  $nowWValue = nowWChanger();

  $sql = "update userprogress set nowW = '{$nowWValue}' where id = '{$_GET['id']}'";
  $result = mysqli_query($db, $sql);
  $target_url = "adminmain.php?date={$_GET['date']}";
	echo "<meta http-equiv='refresh' content='0;url={$target_url}'>";

 ?>
