<?php
  include("head.php");
?>
<style media="screen">
.btn-file {
  position: relative;
  overflow: hidden;
}
.btn-file input[type=file] {
  position: absolute;
  top: 0;
  right: 0;
  min-width: 100%;
  min-height: 100%;
  font-size: 100px;
  text-align: right;
  filter: alpha(opacity=0);
  opacity: 0;
  outline: none;
  background: white;
  cursor: inherit;
  display: block;
}
</style>

<div class="" align="center">
  <h2>자기소개서 예약 페이지</h2>
  <br>
  <table class="table" style="width: 80%; text-align: center">
    <tr>
      <td>주차</td>
      <td>과제</td>
      <td>참고자료</td>
      <td>예약날짜</td>
      <td>예약버튼</td>

      <td>파일제출</td>
    </tr>

    <tr>
        <form class="" action="reserve_detail.php" method="get">

        <?php
          $result = getResult('userprogress','id',$_SESSION['login_user']);
          $row = mysqli_fetch_assoc($result);
          $w = "w".$_SESSION['nowW'];
          $date = $row[$w];
          $w .= "file";
          $filename = $row[$w];
          $result = getResult('reservinfo', 'index', $_SESSION['nowW']);
          $row = mysqli_fetch_assoc($result);
          echo "
          <td>{$row['index']}주차</td>
          <td>{$row['homework']}</td>
          <td>참고자료</td><td>{$date}</td>
          <td>";

          $resultSub = getResult('userdb','id',$_SESSION['login_user']);
          $rowSub = mysqli_fetch_assoc($resultSub);
          if($rowSub['essaytf']=='수강'){
          echo "<button type=\"submit\" class=\"btn btn-default\">예약</button>";
        }else{
          echo "미수강";
        }
          echo "<input type=\"hidden\" name=\"id\" value=\"{$_SESSION['login_user']}\">
          <input type=\"hidden\" name=\"index\" value=\"{$row['index']}\">
          </td>
          ";
        ?>
      </form>

      <td>
        <?php
        if($rowSub['essaytf']=='수강'){
        echo "<form enctype=\"multipart/form-data\" action=\"upload.php\" method=\"post\">
          <label class=\"btn btn-default btn-file\">
            파일첨부 <input type=\"file\" style=\"display: none;\" name=\"myfile\">
          </label>
          <button style=\"margin-left: 10px\" class=\"btn btn-default\">제출</button>
        </form>";
        }else{

        }
         ?>
      </td>
    </tr>
    <tr>
      <td colspan=6>
        <br>
        * 첨부 파일은 doc 파일을 권장하고, 하나의 파일로 합쳐서 업로드 해주시기 바랍니다.<br><br>
      </td>
    </tr>
    <tr>
      <td>
        현직 변호사<br>멘토단
      </td>
      <td>
        -
      </td>
      <td>
        -
      </td>
      <td>
        <?php
        $time;
        for($i = 1; $i<4; $i++){
          $optionvalue = array("","first", "second", "third");
        $sql = "select * from curriculum_special where {$optionvalue[$i]} = '{$_SESSION['login_user']}'";
        $result = mysqli_query($db, $sql);
          $row = mysqli_fetch_assoc($result);
          if($row['time']!=""){
            switch ($i) {
              case '1':
                $time = "9/16 ";
                break;
                case '2':
                $time = "9/17 ";
                break;
                case '3':
                $time = "9/24 ";
                break;

            }
            $time = $time.substr($row['time'],0,5);
          }
          }
          echo $time;
           ?>

      </td>
      <td>

      </td>
      <td>
        -
      </td>
    </tr>

    <tr>
      <td>
        학업계획서<br>변호사 첨삭
      </td>
      <td>
        -
      </td>
      <td>
        -
      </td>
      <td>
        <?php
        $time;
        for($i = 1; $i<5; $i++){
          $optionvalue = array("","first", "second", "third", "fourth");
        $sql = "select * from curriculum_special_sub where {$optionvalue[$i]} = '{$_SESSION['login_user']}'";
        $result = mysqli_query($db, $sql);
          $row = mysqli_fetch_assoc($result);
          if($row['time']!=""){
            switch ($i) {
              case '1':
                $time = "9/28 ";
                break;
                case '2':
                $time = "9/29 ";
                break;
                case '3':
                $time = "9/29 ";
                break;
                case '4':
                $time = "9/30 ";
                break;

            }
            $time = $time.substr($row['time'],0,5);
          }
          }
          echo $time;
           ?>

      </td>
      <td>
        <form class="" action="reserve_detail_special_sub.php" method="get">
   <?php    echo "<button type=\"submit\" class=\"btn btn-default\">예약</button>";?>
 </from>
      </td>
      <td>
        -
      </td>
    </tr>
  </table>
</div>


<?php
  include("foot.php");
 ?>
