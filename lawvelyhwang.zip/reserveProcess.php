
<!DOCTYPE html>
<html>
  <head>
<meta http-equiv='refresh' content='0;url=reserve.php'>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <?php
    session_start();
    function timeClac($index){
      $hour = floor(($index+1)/2) +9;
      $min = $index%2;
      $time = $hour . ":";
      if($min == 0){
        $time .="30";
      }else{
        $time .="00";
      }
      return $time;
    }

    include("config.php");
    if($_GET['tableName'] == "curriculum_special" or $_GET['tableName'] == "curriculum_special_sub"){
      switch ($_GET['day']){
        case 1:
          $day = 'first';
          break;
        case 2:
          $day = 'second';
          break;
        case 3:
          $day = 'third';
          break;
        case 4:
          $day = 'fourth';
          break;
      }
      $sql = "select * from {$_GET['tableName']} where `time` = '{$_GET['index']}'";
      $result = mysqli_query($db, $sql);
      $row = mysqli_fetch_assoc($result);

      if($row[$day] == ''){
        for($i = 1; $i<2; $i++){
          if($_GET['tableName'] == "curriculum_special"){
          $sql = "select * FROM curriculum_special where concat(ifnull(first,\"\"), ifnull(second,\"\"), ifnull(third,\"\")) regexp '{$_SESSION['login_user']}'";
        }elseif ($_GET['tableName'] == "curriculum_special_sub") {
            $sql = "select * FROM curriculum_special_sub where concat(ifnull(first,\"\"), ifnull(second,\"\"), ifnull(third,\"\"), ifnull(fourth,\"\")) regexp '{$_SESSION['login_user']}'";}

        $result = mysqli_query($db, $sql);
        $rowsCount = mysqli_num_rows($result);
        if($rowsCount >= 1){
          $sql = "update {$_GET['tableName']} set first = '' where first = '{$_SESSION['login_user']}'";
          $result = mysqli_query($db, $sql);
          $sql = "update {$_GET['tableName']} set second = '' where second = '{$_SESSION['login_user']}'";
          $result = mysqli_query($db, $sql);
          $sql = "update {$_GET['tableName']} set third = '' where third = '{$_SESSION['login_user']}'";
          $result = mysqli_query($db, $sql);
          $sql = "update {$_GET['tableName']} set fourth = '' where fourth = '{$_SESSION['login_user']}'";
          $result = mysqli_query($db, $sql);
        }
        }
          $sql = "update {$_GET['tableName']} set {$day} = '{$_SESSION['login_user']}' where `time` = '{$_GET['index']}'";
          $result = mysqli_query($db, $sql);

        }else{
        echo "<script>alert('이미 예약 된 시간 입니다. 다른 시간에 예약해 주십시오.');history.back();</script>";
        exit;
      }

    }else{
    switch ($_GET['day']){
      case 1:
        $day = 'mon';
        break;
      case 2:
        $day = 'tue';
        break;
      case 3:
        $day = 'wed';
        break;
      case 4:
        $day = 'thu';
        break;
      case 5:
        $day = 'fri';
        break;
      case 6:
        $day = 'sat';
        break;
      case 7:
        $day = 'sun';
        break;
    }
    echo "예약 중 입니다.";

    $sql = "select * from {$_GET['tableName']} where `time` = '{$_GET['index']}'";
    $result = mysqli_query($db, $sql);
    $row = mysqli_fetch_assoc($result);
    if($row[$day] == ''){
      for($i = 1; $i<7; $i++){
      $sql = "select * FROM curriculum_week{$i} where concat(mon,tue,wed,thu,fri,sat,sun) regexp '".$_SESSION['login_user']."-"."{$_SESSION['nowW']}'";
      $result = mysqli_query($db, $sql);
      $rowsCount = mysqli_num_rows($result);
      if($rowsCount >= 1){
        $sql = "update curriculum_week{$i} set mon = '' where mon = '{$_SESSION['login_user']}"."-"."{$_SESSION['nowW']}'";
        $result = mysqli_query($db, $sql);
        $sql = "update curriculum_week{$i} set tue = '' where tue = '{$_SESSION['login_user']}"."-"."{$_SESSION['nowW']}'";
        $result = mysqli_query($db, $sql);
        $sql = "update curriculum_week{$i} set wed = '' where wed = '{$_SESSION['login_user']}"."-"."{$_SESSION['nowW']}'";
        $result = mysqli_query($db, $sql);
        $sql = "update curriculum_week{$i} set thu = '' where thu = '{$_SESSION['login_user']}"."-"."{$_SESSION['nowW']}'";
        $result = mysqli_query($db, $sql);
        $sql = "update curriculum_week{$i} set fri = '' where fri = '{$_SESSION['login_user']}"."-"."{$_SESSION['nowW']}'";
        $result = mysqli_query($db, $sql);
        $sql = "update curriculum_week{$i} set sat = '' where sat = '{$_SESSION['login_user']}"."-"."{$_SESSION['nowW']}'";
        $result = mysqli_query($db, $sql);
        $sql = "update curriculum_week{$i} set sun = '' where sun = '{$_SESSION['login_user']}"."-"."{$_SESSION['nowW']}'";
        $result = mysqli_query($db, $sql);
      }
      }
        $sql = "update {$_GET['tableName']} set {$day} = '{$_SESSION['login_user']}"."-"."{$_SESSION['nowW']}' where `time` = '{$_GET['index']}'";
        $result = mysqli_query($db, $sql);

        $sql = "select * from userprogress where `id` = '{$_SESSION['login_user']}'";
        $result = mysqli_query($db, $sql);
        $row = mysqli_fetch_assoc($result);

        $week = substr($_GET['tableName'],15);

        $wDay = 900+($week-1)*7+$_GET['day']+3;
        if($wDay>930){
          $wDay = $wDay+70;
        }elseif($wDay <= 900){

        }

        $time = timeClac($_GET['index']);

        $sql = "update userprogress set w".$row['nowW']."date = '".$wDay."' where `id` = '{$_SESSION['login_user']}'";
        mysqli_query($db, $sql);

        $sql = "update userprogress set w".$row['nowW']."hour = '".$time."' where `id` = '{$_SESSION['login_user']}'";
        mysqli_query($db, $sql);
        if(substr($wDay,0,1) == 1){
          $wDay = substr($wDay,0,2)."월 ".substr($wDay,2)."일 ".$time;
        }else {
          $wDay = substr($wDay,0,1)."월 ".substr($wDay,1)."일 ".$time;
        }

        $sql = "update userprogress set w".$row['nowW']." = '".$wDay."' where `id` = '{$_SESSION['login_user']}'";
        mysqli_query($db, $sql);
      }else{
      echo "<script>alert('이미 예약 된 시간 입니다. 다른 시간에 예약해 주십시오.');history.back();</script>";
      exit;
    }

  }

    ?>

  </body>
</html>
