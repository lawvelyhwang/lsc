<?php
  include("head.php");
?><div class="" align="center">
  <h2>자기소개서 예약 페이지</h2>
  <br>
  <span style="color:#ffeeee"> &#9679; </span>- 신촌 | <span style="color:#fdf8d6"> &#9679; </span> - 강남
  <br>
  <br>
  <?php echo "<form action=\"reserve_detail.php\" method=\"get\">"; ?>
    <div class="input-group" style="width: 80%;">
      <select class="form-control" name="aweek">
        <option>다른 기간 선택</option>
        <option value="4">9/25 ~ 10/1</option>
        <option value="5">10/2 ~ 10/8</option>
        <option value="6">10/9 ~ 10/14</option>
      </select>
      <?php
        echo "<input type=\"hidden\" name=\"id\" value=\"{$_GET['id']}\">";
        echo "<input type=\"hidden\" name=\"index\" value=\"{$_GET['index']}\">";
       ?>
      <span class="input-group-btn">
        <button class="btn btn-default" type="submit">검색</button>
      </span>
    </div>
  </form>
  <br>
<div class="" align="center">
  <table class="table" style="width: 80%; text-align: center;">
    <tr>
      <td>시간</td>
      <td>월</td>
      <td>화</td>
      <td>수</td>
      <td>목</td>
      <td>금</td>
      <td>토</td>
      <td>일</td>
    </tr>
    <?php
      $tableName = 'calander';
      if($_GET['aweek']==null){
      $result = getResult($tableName, 'week', 1);
    }else{
      $result = getResult($tableName, 'week', $_GET['aweek']);
    }
      while($row = mysqli_fetch_assoc($result)){
        echo "<tr>";
        echo "<td>"."</td>";
        echo "<td>".$row['mon']."</td>";
        echo "<td>".$row['tue']."</td>";
        echo "<td>".$row['wed']."</td>";
        echo "<td>".$row['thu']."</td>";
        echo "<td>".$row['fri']."</td>";
        echo "<td>".$row['sat']."</td>";
        echo "<td>".$row['sun']."</td>";
        echo "</tr>";
      }
      if($_GET['aweek']==null){
      $tableName = 'curriculum_week'.$_GET['index'];
    }else{
      $tableName = 'curriculum_week'.$_GET['aweek'];
    }

      $result = getResult($tableName, '','','all');

      while($row = mysqli_fetch_assoc($result)){
        $time = timeClac($row['time']);
        $dayValue = array(
          dayCalc($row['time'],$row['mon'],1,$tableName,1),
          dayCalc($row['time'],$row['tue'],2,$tableName,0),
          dayCalc($row['time'],$row['wed'],3,$tableName,1),
          dayCalc($row['time'],$row['thu'],4,$tableName,0),
          dayCalc($row['time'],$row['fri'],5,$tableName,0),
          dayCalc($row['time'],$row['sat'],6,$tableName,0),
          dayCalc($row['time'],$row['sun'],7,$tableName,0)
        );

        echo "<tr>";
        echo "<td>".$time."</td>";
        echo "<td".$dayValue[0]."</td>";
        echo "<td".$dayValue[1]."</td>";
        echo "<td".$dayValue[2]."</td>";
        echo "<td".$dayValue[3]."</td>";
        echo "<td".$dayValue[4]."</td>";
        echo "<td".$dayValue[5]."</td>";
        echo "<td".$dayValue[6]."</td>";
        echo "</tr>";
      }
     ?>

  </table>
</div>

<?php
  include("foot.php");
 ?>
