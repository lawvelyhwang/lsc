<?php
  include("head.php");
?><div class="" align="center">
  <h2>시뮬레이션 예약 페이지</h2>
  <br>
  * 예약시간 30분 전에는 꼭 도착해주세요.<br><br><br>
  <br>
  <br>
  <?php echo "<form action=\"reserve_process_simul.php\" method=\"get\">"; ?>
    <div class="input-group" style="width: 80%;">
      <?php
        echo "<input type=\"hidden\" name=\"id\" value=\"{$_GET['id']}\">";
        echo "<input type=\"hidden\" name=\"index\" value=\"{$_GET['index']}\">";
       ?>

    </div>
  </form>
  <br>
<div class="" align="center">
  <table class="table" style="width: 80%; text-align: center;">
    <tr>
     <?php
      echo "<td>시간</td>";
        if ($_GET['class'] == 1){
      if($_GET['idx']==1){
        echo       "<td>11/4</td>";}
        if($_GET['idx']==2){
            echo "<td>11/5</td>";}
      if($_GET['idx']==3){
            echo "<td>11/7</td>";
      echo "<td>11/8</td>";}
        }else{
            if($_GET['idx']==1){
            echo  "<td>11/11</td>";}
      if($_GET['idx']==2){
          echo "<td>11/12</td>";}
      if($_GET['idx']==3){
          echo "<td>11/13</td>";
      echo "<td>11/14</td>";}
        }
         
     ?>
      
    </tr>
    <tr>
      <td>구분</td>
      
    <?php
      if($_GET['idx']==1){
        echo "<td>모의 1회</td>";}
      if($_GET['idx']==2){
        echo "<td>모의 2회</td>";}
      if($_GET['idx']==3){
        echo "<td>개인 강평</td>";
        echo "<td>개인 강평</td>";}
    ?>
    </tr>
    <?php
      $tableName = 'simul'.$_GET['class'];

      $result = getResult($tableName, '-', '-', 'all'); 
      while($row = mysqli_fetch_assoc($result)){
        $time = substr($row['idx'],0,5);
      
            $dayValue = array(
          dayCalc2($row['idx'],$row['lec01'],1,$tableName,0),
          dayCalc2($row['idx'],$row['lec02'],2,$tableName,0),
          dayCalc2($row['idx'],$row['lec03'],3,$tableName,0),
          dayCalc2($row['idx'],$row['lec04'],4,$tableName,0)
        );  
          

        echo "<tr>";
        echo "<td>".$time."</td>";
        if($_GET['idx']==1){
        echo "<td".$dayValue[0]."</td>";}
        if($_GET['idx']==2){
        echo "<td".$dayValue[1]."</td>";}
        if($_GET['idx']==3){
          echo "<td".$dayValue[2]."</td>";
        
        echo "<td".$dayValue[3]."</td>";
        }
        echo "</tr>";
      }

     ?>

  </table>
</div>

<?php
  include("foot.php");
 ?>
