<?php
  include("head.php");
?><div class="" align="center">
  <h2>자기소개서 예약 페이지</h2>
  <br>
  * 예약시간 10분 전에는 꼭 도착해주세요.<br><br>
  * 자소서, 구상 초안 및 질의 사항 등을 미리 준비해주세요.<br><br>
  * 이 시간에는 학교 선택보다는 진로나 업계현황에 관한 질문을 해주셨으면 좋겠습니다.<br>
  <br>
  <br>
  <?php echo "<form action=\"reserve_detail.php\" method=\"get\">"; ?>
    <div class="input-group" style="width: 80%;">
      <?php
        echo "<input type=\"hidden\" name=\"id\" value=\"{$_GET['id']}\">";
        echo "<input type=\"hidden\" name=\"index\" value=\"{$_GET['index']}\">";
       ?>

    </div>
  </form>
  <br>
<div class="" align="center">
  <table class="table" style="width: 80%; text-align: center;">
    <tr>
      <td>시간</td>
      <td>9/16</td>
      <td>9/17</td>
      <td>9/24</td>

    </tr>
    <tr>
      <td>특징</td>
      <td>기업법무</td>
      <td>금융계</td>
      <td>기업법무</td>

    </tr>
    <?php
      $tableName = 'curriculum_special';

      $result = getResult($tableName, 'week', $_GET['aweek'], 'all');
      while($row = mysqli_fetch_assoc($result)){
        $time = substr($row['time'],0,5);
        $dayValue = array(
          dayCalc($row['time'],$row['first'],1,$tableName,0),
          dayCalc($row['time'],$row['second'],2,$tableName,0),
          dayCalc($row['time'],$row['third'],3,$tableName,0)
        );

        echo "<tr>";
        echo "<td>".$time."</td>";
        echo "<td".$dayValue[0]."</td>";
        echo "<td".$dayValue[1]."</td>";
        echo "<td".$dayValue[2]."</td>";
        echo "</tr>";
      }

     ?>

  </table>
</div>

<?php
  include("foot.php");
 ?>
