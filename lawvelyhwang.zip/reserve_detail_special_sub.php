<?php
  include("head.php");
?><div class="" align="center">
  <h2>자기소개서 예약 페이지</h2>
  <br>
  * 예약시간 10분 전에는 꼭 도착해주세요.<br><br>
  <br>
  <br>
  <?php echo "<form action=\"reserve_detail.php\" method=\"get\">"; ?>
    <div class="input-group" style="width: 80%;">
      <?php
        echo "<input type=\"hidden\" name=\"id\" value=\"{$_GET['id']}\">";
        echo "<input type=\"hidden\" name=\"index\" value=\"{$_GET['index']}\">";
       ?>

    </div>
  </form>
  <br>
<div class="" align="center">
  <table class="table" style="width: 80%; text-align: center;">
    <tr>
      <td></td>
      <td>9/28 목</td>
      <td>9/29 금</td>
      <td>9/29 금</td>
      <td>9/30 토</td>

    </tr>
    <tr>
      <td></td>
      <td>정동주<br>변호사</td>
      <td>정동주<br>변호사</td>
      <td>최웅구<br>변호사</td>
      <td>정동주<br>변호사</td>
    </tr>

    <tr>
      <td>시간</td>
      <td>학업계획서</td>
      <td>학업계획서</td>
      <td>로클럭, 검찰</td>
      <td>학업계획서</td>
    </tr>
    <?php
      $tableName = 'curriculum_special_sub';

      $result = getResult($tableName, 'week', $_GET['aweek'], 'all');
      while($row = mysqli_fetch_assoc($result)){
        $time = substr($row['time'],0,5);
        $dayValue = array(
          dayCalc($row['time'],$row['first'],1,$tableName,0),
          dayCalc($row['time'],$row['second'],2,$tableName,0),
          dayCalc($row['time'],$row['third'],3,$tableName,0),
          dayCalc($row['time'],$row['fourth'],4,$tableName,0)
        );

        echo "<tr>";
        echo "<td>".$time."</td>";
        echo "<td".$dayValue[0]."</td>";
        echo "<td".$dayValue[1]."</td>";
        echo "<td".$dayValue[2]."</td>";
        echo "<td".$dayValue[3]."</td>";
        echo "</tr>";
      }

     ?>

  </table>
</div>

<?php
  include("foot.php");
 ?>
