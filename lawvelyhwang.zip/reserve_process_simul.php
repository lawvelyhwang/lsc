
<!DOCTYPE html>
<html>
  <head>
<meta http-equiv='refresh' content='0;url=reserve_simul.php'>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <?php
    session_start();
    function timeClac($index){
      $hour = floor(($index+1)/2) +9;
      $min = $index%2;
      $time = $hour . ":";
      if($min == 0){
        $time .="30";
      }else{
        $time .="00";
      }
      return $time;
    }

    include("config.php");
      switch ($_GET['day']){
        case 1:
          $day = 'lec01';
          break;
        case 2:
          $day = 'lec02';
          break;
        case 3:
          $day = 'lec03';
          break;
        case 4:
          $day = 'lec04';
          break;
      }
      $sql = "select * from {$_GET['tableName']} where `idx` = '{$_GET['index']}'";
      $result = mysqli_query($db, $sql);
      $row = mysqli_fetch_assoc($result);

      if($row[$day] == ''){
        for($i = 1; $i<2; $i++){
          
          $sql = "select * FROM {$_GET['tableName']} where `{$day}` ='{$_SESSION['login_user']}'";
            if($day == 'lec03' or $day =='lec04'){
                $sql =  "select * FROM {$_GET['tableName']} where lec03 ='{$_SESSION['login_user']}' or lec04 = '{$_SESSION['login_user']}'";
            }

        $result = mysqli_query($db, $sql);
        $rowsCount = mysqli_num_rows($result);
        if($rowsCount >= 1){
          $sql = "update {$_GET['tableName']} set {$day} = '' where {$day} = '{$_SESSION['login_user']}'";
          $result = mysqli_query($db, $sql);
        if($day == 'lec03' or $day =='lec04'){
            $sql = "update {$_GET['tableName']} set lec03 = '' where lec03 = '{$_SESSION['login_user']}'";
            $result = mysqli_query($db, $sql);
            $sql = "update {$_GET['tableName']} set lec04 = '' where lec04 = '{$_SESSION['login_user']}'";
            $result = mysqli_query($db, $sql);
        }
        }
        }
          $sql = "update {$_GET['tableName']} set {$day} = '{$_SESSION['login_user']}' where `idx` = '{$_GET['index']}'";
          $result = mysqli_query($db, $sql);

        }else{
        echo "<script>alert('이미 예약 된 시간 입니다. 다른 시간에 예약해 주십시오.');history.back();</script>";
        exit;
      }

    

  

    ?>

  </body>
</html>
