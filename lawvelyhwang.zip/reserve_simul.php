<?php
  include("head.php");
?>
<style media="screen">
.btn-file {
  position: relative;
  overflow: hidden;
}
.btn-file input[type=file] {
  position: absolute;
  top: 0;
  right: 0;
  min-width: 100%;
  min-height: 100%;
  font-size: 100px;
  text-align: right;
  filter: alpha(opacity=0);
  opacity: 0;
  outline: none;
  background: white;
  cursor: inherit;
  display: block;
}
</style>

<div class="" align="center">
  <h2>시뮬레이션 예약 페이지</h2>
  <br>
  <table class="table" style="width: 80%; text-align: center">
    <tr>
      <td>회차</td>
      <td>구분</td>
      <td>예약시간</td>
      <td>예약버튼</td>
    </tr>

    <tr>
        <form class="" action="reserve_detail_simul.php" method="get">

        <?php
          $result = getResult('simul_table','id',$_SESSION['login_user']);
          $row = mysqli_fetch_assoc($result);
          $w = "class";
          $class = $row[$w];
        
            
        $tableName = "simul".$class;
        $result = getResult($tableName,'lec01',$_SESSION['login_user']);
          $row = mysqli_fetch_assoc($result);
          $w = "idx";
          $date =  "토요일 ".$row[$w];
          echo "
          <td>1일차</td>
          <td>로스쿨 출신 변호사 3인</td>
          <td>{$date}</td>
          <td>";
         
          echo "<button type=\"submit\" class=\"btn btn-default\">예약</button>";
          echo "<input type=\"hidden\" name=\"id\" value=\"{$_SESSION['login_user']}\">
          <input type=\"hidden\" name=\"idx\" value=\"1\">
          <input type=\"hidden\" name=\"class\" value=\"{$class}\">
          </td>
          ";
        ?>
      </form>

    </tr>
    
        <tr>
        <form class="" action="reserve_detail_simul.php" method="get">

        <?php
$tableName = "simul".$class;
    $result = getResult($tableName,'lec02',$_SESSION['login_user']);
          $row = mysqli_fetch_assoc($result);
          $w = "idx";
          $date =  "일요일 ".$row[$w];
          
          echo "
          <td>2일차</td>
          <td>10년차 이상 경력 변호사 3인</td>
          <td>{$date}</td>
          <td>";

           echo "<button type=\"submit\" class=\"btn btn-default\">예약</button>";
          echo "<input type=\"hidden\" name=\"id\" value=\"{$_SESSION['login_user']}\">
          <input type=\"hidden\" name=\"idx\" value=\"2\">
          <input type=\"hidden\" name=\"class\" value=\"{$class}\">
          </td>
          ";
        ?>
      </form>

    </tr>
    
     <tr>
        <form class="" action="reserve_detail_simul.php" method="get">

        <?php
$tableName = "simul".$class;
    $result = getResult($tableName,'lec03',$_SESSION['login_user']);
          $row = mysqli_fetch_assoc($result);
          $w = "idx";
        if($class == 1){
          $date = "화요일 ".$row[$w];
        
            if($date == '화요일 '){
                $tableName = 'simul'.$class;
        $result = getResult($tableName,'lec04',$_SESSION['login_user']);
          $row = mysqli_fetch_assoc($result);
          $w = "idx";
          $date = "수요일 ".$row[$w];
        
            }}else{
            $date = "월요일 ".$row[$w];
        
            if($date == '월요일 '){
                $tableName = 'simul'.$class;
        $result = getResult($tableName,'lec04',$_SESSION['login_user']);
          $row = mysqli_fetch_assoc($result);
          $w = "idx";
          $date = "화요일 ".$row[$w];
        
            }
            
        }
          echo "
          <td>4일차</td>
          <td>개인강평</td>
          <td>{$date}</td>
          <td>";

          echo "<button type=\"submit\" class=\"btn btn-default\">예약</button>";
          echo "<input type=\"hidden\" name=\"id\" value=\"{$_SESSION['login_user']}\">
          <input type=\"hidden\" name=\"idx\" value=\"3\">
          <input type=\"hidden\" name=\"class\" value=\"{$class}\">
          </td>
          ";
        ?>
      </form>

    </tr>
  </table>
</div>


<?php
  include("foot.php");
 ?>
