<?php
  include("adminhead.php");
  include("config.php");

  function check($id, $clNum){
    global $db;
    $checker;
    $sql = "select * from rollbook1 where id = '{$id}'";
    $result = mysqli_query($db, $sql);
    $row = mysqli_fetch_assoc($result);

    $w = "num".$clNum;
    if($row[$w]=='O'){
      $checker = "X";
    }else{
      $checker = "O";
    }
    $sql = "update rollbook1 set {$w} = '{$checker}' where id = '{$id}'";
    mysqli_query($db, $sql);
    $target_url = "rollbookAdmin.php?class={$_GET['class']}";
    header("Location: {$target_url}");
  }
  if($_GET['id']!=null&&$_GET['clNum']!=null){
  check($_GET['id'], $_GET['clNum']);}
 ?>
 <script type="text/javascript">
     document.getElementById("list").className = "btn btn-default";
     document.getElementById("listweek").className = "btn btn-default";
     document.getElementById("rollbook").className = "btn btn-primary";

 </script>
<br>
<form class="" action="rollbookAdmin.php" method="get">
  <div class="">
    <select class="form-control" name="class" style="width:89%; display:inline-block;">
      <option value="1">신촌 월수 오전</option>
      <option value="2">강남 월수 오후</option>
      <option value="3">강남 화목 오전</option>
      <option value="4">강남 화목 오후</option>
      <option value="5">강남 주말</option>
    </select>
    <input type="submit" style="width: 10%; display:inline-block;margin-bottom: 5px;" class="btn btn-default" value="확인">
  </div>
</form>
<br>
<?php
$clname;
  switch ($_GET['class']) {
  case 1:
 $clname = "신촌 월수 오전";
  break;
  case 2:
 $clname =  "강남 월수 오후";
  break;
  case 3:
  $clname =  "강남 화목 오전";
  break;
  case 4:
  $clname =  "강남 화목 오후";
  break;
  case 5:
  $clname =  "강남 주말";
  break;
}
$sql = "select name, id, pNumber, essaytf from userdb where class = '{$clname}'";
$result = mysqli_query($db, $sql);
$row_cnt = mysqli_num_rows($result);
 echo "<div align=\"center\">";
 echo "{$clname}<br>총 인원 : ".$row_cnt."</div><br><br>";

 ?>

  <table class="table" style=" text-align: center; background: #fffdf1;" >
    <tr>
      <td colspan="1">이름</td>
      <td colspan="1">자소서</td>
      <td colspan="1">세부</td>
      <td colspan="1">문자</td>
    </tr>

      <?php
      $className;
        switch ($_GET['class']) {
          case 1:
          $className ="신촌 월수 오전";
          break;
          case 2:
          $className ="강남 월수 오후";
          break;
          case 3:
          $className ="강남 화목 오전";
          break;
          case 4:
          $className ="강남 화목 오후";
          break;
          case 5:
          $className ="강남 주말";
          break;
        }

          while($row = mysqli_fetch_assoc($result)){
            echo "<tr>";
            echo "<td style=\"background: #fffef8;\" >{$row['name']}</td>";
            echo "<td style=\"background: #fffef8;\">{$row['essaytf']}</td>";
            echo "<td style=\"background: #fffef8;\"><a>";
            echo "<form name=\"userform\" method=\"post\" action=\"./analysis/process.php\">";
            $sql = "select * from userdb where `id` = '{$row['id']}'";
            $result12 = mysqli_query($db, $sql);
            $row12 = mysqli_fetch_assoc($result12);
            echo "<input type=\"hidden\" name=\"leetApure\" value=\"{$row12['leetApure']}\">";
            echo "<input type=\"hidden\" name=\"leetBpure\" value=\"{$row12['leetBpure']}\">";
            echo "<input type=\"hidden\" name=\"radio\" value=\"{$row12['gpaIndex']}\">";
            echo "<input type=\"hidden\" name=\"schoolScore\" value=\"{$row12['gpa']}\">";
            echo "<input type=\"hidden\" name=\"radioEng\" value=\"{$row12['engIndex']}\">";
            echo "<input type=\"hidden\" name=\"engScore\" value=\"{$row12['eng']}\">";
            echo "<input type=\"submit\" class=\" btn btn-default \" value=\"정보\">
            </form>";

            echo "</a></td>";
            echo "<td style=\"background: #fffef8;\"><a href=\"sms:+82{$row['pNumber']}\" class=\"btn btn-default\">문자</a></td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td>1회</td>";
            echo "<td>2회</td>";
            echo "<td>3회</td>";
            echo "<td>4회</td>";

            echo "</tr>";
            $sql = "select * from rollbook1 where id = '{$row['id']}'";
            $resultsub = mysqli_query($db,$sql);
            $rowSub = mysqli_fetch_assoc($resultsub);
            echo "<tr>";
            for($i=1; $i<5; $i++){
                $w = "num".$i;
                echo "<td style=\"background: #fffef8;\">".$rowSub[$w]."</td>";
            }
            echo "<tr></tr>";
            for($i=1; $i<5; $i++){
                $w = "num".$i;
                echo "<td style=\"background: #fffef8;\">"."<a class=\"btn btn-default\" href=\"?class={$_GET['class']}&id={$row['id']}&clNum={$i}\">".출결."</a></td>";
            }
            echo "</tr>";
            echo "<tr>";
            echo "<td>5회</td>";
            echo "<td>6회</td>";
            echo "<td>7회</td>";
            echo "<td>8회</td>";
            echo "<tr></tr>";
            for($i=5; $i<9; $i++){
                $w = "num".$i;
                echo "<td style=\"background: #fffef8;\">".$rowSub[$w]."</td>";
            }
            echo "<tr></tr>";
            for($i=5; $i<9; $i++){
                $w = "num".$i;
                echo "<td style=\"background: #fffef8;\">"."<a class=\"btn btn-default\" href=\"?class={$_GET['class']}&id={$row['id']}&clNum={$i}\">".출결."</a></td>";
            }
            echo "</tr>";
            echo "<tr><td colspan=\"4\" style=\"background: white;\"><br><br></td></tr>";
          }

       ?>



  </table>

 <?php
  include("adminfoot.php");
  ?>
