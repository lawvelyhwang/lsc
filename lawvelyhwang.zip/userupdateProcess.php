
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    session_start();
      include("config.php");
      $salt = '$2a$07$R.gJb2U2N.FmZ4hPp1y2CN$';
      $passwd = crypt($_POST['pwd'], $salt);

      $pwd = mysqli_real_escape_string($db, $passwd);
      $name = mysqli_real_escape_string($db, $_POST['name']);
      $pNumber = mysqli_real_escape_string($db, $_POST['pNumber']);
      $class = mysqli_real_escape_string($db, $_POST['class']);
      $school = mysqli_real_escape_string($db, $_POST['school']);
      $major = mysqli_real_escape_string($db, $_POST['major']);
      $gpa = mysqli_real_escape_string($db, $_POST['gpa']);
      $gpaIndex = mysqli_real_escape_string($db, $_POST['gpaIndex']);
      $leetApure = mysqli_real_escape_string($db, $_POST['leetApure']);
      $leetBpure = mysqli_real_escape_string($db, $_POST['leetBpure']);
      $eng = mysqli_real_escape_string($db, $_POST['eng']);
      $engIndex = mysqli_real_escape_string($db, $_POST['engIndex']);
      $essayTF = mysqli_real_escape_string($db, $_POST['essayTF']);

      $sql = "select * from userdb where id = '".$_SESSION['login_user']."'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_assoc($result);

        $sql = "update userdb set `password`= '{$pwd}', `name` = '{$name}', `pNumber` = '{$pNumber}', `class` = '{$class}', `school` = '{$school}',
        `pNumber` = '{$pNumber}', `pNumber` = '{$pNumber}', `pNumber` = '{$pNumber}'
        , `major` = '{$major}', `gpa` = '{$gpa}', `gpaIndex` = '{$gpaIndex}', `leetApure` = '{$leetApure}', `leetBpure` = '{$leetBpure}', `eng` = '{$eng}'
        , `engIndex` = '{$engIndex}', `essaytf` = '{$essayTF}' where `id` = '{$_SESSION['login_user']}'";
      $result = mysqli_query($db,$sql);

        echo "<script>alert('변경 되었습니다.');history.back();</script>";
        exit;

     ?>
  </body>
</html>
